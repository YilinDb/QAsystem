import json
from torch.utils.data import Dataset

class HotpotDataset(Dataset):
    def __init__(self, dataset_path):
        super().__init__()
        with open(dataset_path) as json_file:
            data = json.load(json_file)
        self.corpus = []
        self.qa = []
        for entries in data:
            self.corpus.append(entries["context"])
            self.qa.append([entries["answer"], entries["question"]])
        return

    def __len__(self):
        return len(self.qa)
    
    def __getitem__(self, index):
        """
            output as a dict contains:
            1. context: passage
            2. question: question
            3. answer: the answer to the question
            4. is_impossible: whether there is an answer for the question
        """
        qa_entry = self.qa[index]
        ret = {}
        ret['context'] = self.corpus[index]
        ret['answer'] = qa_entry[0]
        ret['question'] = qa_entry[1]
        ret['is_impossible'] = False
        return ret
