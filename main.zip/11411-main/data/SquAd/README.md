# Overview
Stanford Question Answering Dataset (SQuAD) is a reading comprehension dataset, consisting of questions posed by crowdworkers on a set of Wikipedia articles, where the answer to every question is a segment of text, or span, from the corresponding reading passage, or the question might be unanswerable.

## Structure
SQuAD contains 40MB Training Dataset and 4MB Validation Dataset.
In each dataset, it consists of one long json string. After json dumps, you can easily get the information below:
1. version(Dataset Version is 2.0)
2. data
   Element in the list represents one full paragraph in a long text(like GRE reading). It will be split into small paragraphs and each small piece has its own questions.
   1. title: The title of long text
   2. paragraphs: each paragraphs is a split piece of original text
      1. context: the material in the paragraph
      2. qas: questions and answers
         1. question
         2. answer
            1. text: answer text
            2. answer begin: the begin part in the text to find the corresponding answer
         3. id
         4. if possible: some of the question could not be answered by the text provided

## Code 
A Data Set Class is implemented in data.py. You just need to verify the output of getitem function. The output is in text formats.