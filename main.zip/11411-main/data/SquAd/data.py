import json
from torch.utils.data import Dataset

class SQuADDataset(Dataset):
    def __init__(self, dataset_path):
        super().__init__()
        with open(dataset_path, 'r') as json_file:
            data = json.load(json_file)['data']
        self.corpus = []
        self.qa = []
        for passage in data:
            for qa in passage['paragraphs']:
                context = qa['context']
                self.corpus.append(context)
                for question in qa['question']:
                    text_id = len(self.corpus) - 1
                    qa_bag = dict()
                    qa_bag['text_id'] = text_id
                    qa_bag['question'] = question['question']
                    qa_bag['answer'] = question['answers']['text']
                    qa_bag['pos'] = question['answers']['answer_start']
                    qa_bag['is_impossible'] = question['is_impossible']
                    self.qa.append(qa_bag)

    def __len__(self):
        return len(self.qa)
    
    def __getitem__(self, index):
        """
            output as a dict contains:
            1. context: passage
            2. question: question
            3. answer: the answer to the question
            4. is_impossible: whether there is an answer for the question
        """
        qa_bag = self.qa[index]
        ret = {}
        ret['context'] = self.corpus[qa_bag['text_id']]
        ret['question'] = qa_bag['question']
        ret['answer'] = qa_bag['answer']
        ret['is_impossible'] = qa_bag['is_impossible']
        return ret
