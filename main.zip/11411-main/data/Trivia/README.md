# Overview
Trivia QA has 110k question-answer pairs with 6 documents as evidence on average, which is 650k question-answer-evidence triples in total.
TriviaQA: A Large Scale Distantly Supervised Challenge Dataset for Reading Comprehension In Association for Computational Linguistics (ACL) 2017, Vancouver, Canada.

# Access
The dataset can be donwloaded from the official website https://nlp.cs.washington.edu/triviaqa/

# Other 
If you have a SQuAD model and want to run on TriviaQA, please refer to utils.convert_to_squad_format.py in TriviaQA repo(https://github.com/mandarjoshi90/triviaqa)
