# About Dataset
TyDi QA is a question answering dataset covering 11 typologically diverse languages with 204K question-answer pairs. It can accomodate linguistic features of different language expressions, e.g. question and answer pairs that contain different spelling for a same non-native word, or one in English expression one in the other language which causes disparity in spelling and culture difference in question and answer text .
</br>
</br>
*Note: the dataset tests subtasks that are nearly trivial in English—such as string matching-which would become complex for languages where morphophonological alternations and compounding cause dramatic variations in word forms (e.g.Arabic).*


# Data Collection:
The articles for TyDi QA are drawn from single coherent snapshots of Wikipedia from the Internet Archive to enable open-retrieval experiments. Questions are written by people who are given short prompts of Wikipedia articles and want to know the answer, but don’t know the answer yet.
A Wikipedia article is then paired with each question by performing a Google search on the question text, restricted to the Wikipedia domain for each language, and selecting the top-ranked result.
Annotators are presented with the question/article pair and asked to select the best passage answer—a paragraph in the article that contains an answer—or else indicate no answer (NULL). If a passage is found, annotators are asked to find a minimal answer--a span as short as possible that can form a satisfactory answer to the question, or YES/NO for binary question.
No translation nor modeling was used to create the dataset (lower lexical overlap).



# Description of the data


```
[data.py] - Responsible for deserializing the JSON and creating Pythonic data structures. Usable by any ML framework / no TF dependencies

[tokenization.py] - Fork of BERT's tokenizer that tracks byte offsets. Usable by any ML framework / no TF dependencies

[preproc.py] - Calls tokenization and munges JSON into a format usable by the model. Usable by any ML framework / no TF dependencies

[tf_io.py] - Tensorflow-specific IO code (reads tf.Examples from TF records). If you'd like to use your own favorite DL framework, you'd need to modify this; it's only about 200 lines.

[tydi_modeling.py] - The core TensorFlow model code. If you want to replace BERT with your own latest and greatest, start here! Similarly, if you'd like to use your own favorite DL framework, this would be the only file that should require heavy modification; it's only about 200 lines.

[postproc.py] - Does postprocessing to find the answer, etc. Relevant only for inference (not used in training). Usable by any ML framework with minimal edits. Has minimal tf dependencies (e.g. a few tensor post-processing functions).

[run_tydi.py] - The main driver script that uses all of the above and calls Tensorflow to do the main training and inference loops.
```

# Tasks
*NULL consensus:* for each evaluation example, at least 2 of all 3 annotators must select an answer for the consensus to be non-NULL. If the answer is NULL, it means we cannot find an answer from the documents given.
</br>
## Primary tasks
A fuller and more robust representative of information-seeking question answering. 
A baseline system based on multilingual BERT (mBERT) is provided, requires 16 GB of GPU RAM for mBERT. It is designed to be easily re-used with instruction and data structure in baseline README file.

- **Passage selection task (SelectP):**
  Given a list of the passages in the article, return either (a) the index of the passage that answers the question or (b) NULL if no such passage exists.
  
- **Minimal answer span task (MinSpan):**
   Given the full text of an article, return one of (a) the start and end byte indices of the minimal span that completely answers the question; (b) YES or NO if the question requires a yes/no answer and we can draw a conclusion from the passage; (c) NULL if it is not possible to produce a minimal answer for this question.
  Minimal answers are not necessary to include function words or be full sentences.

### Evaluation:
computes language-wise F1 scores and then averages over languages, excluding English. Spans are compared based on predicted byte positions and partial credit is assigned within spans based on F1 positional overlap.</br>
Measurements on English are treated as a useful means of debugging rather than a goal of the TYDI QA task as there is already plenty of coverage for English evaluation in existing datasets.</br>
https://github.com/google-research-datasets/tydiqa/blob/master/tydi_eval.py
</br>
- **Passage selection task:**
  - For questions having a NULL consensus, credit is given for matching any of the passage indices selected by annotators.An example counts toward the denominator of recall if it has a non-NULL consensus, and toward the denominator of precision if the model predicted a non-NULL answer.
  </br>
- **Minimal span task:**
  - For each example, given the question and text of an article, a system must predict NULL, YES, NO, or a contiguous span of bytes that constitutes the answer.
  - For span answers, we treat this collection of byte index pairs as a set and compute an example-wise F1 score between each annotator’s minimal answer and the model’s minimal answer, with partial credit assigned when spans are partially overlapping;the maximum is returned as the score for each example.
  - For a YES/NO answers, credit is given (a score of 1.0), if any of the annotators indicated such as a correct answer.
  - The NULL consensus must be non-NULL in order to receive credit for a non-NULL answer.
- **Macro-averaging:**
  - the scores for each example are averaged within a language;
  - average over all non-English languages to obtain a final F1 score.

### Download:
The primary task training set is about 1.6GB while the dev set is about 150MB.
https://storage.googleapis.com/tydiqa/v1.0/tydiqa-v1.0-dev.jsonl.gz
https://storage.googleapis.com/tydiqa/v1.0/tydiqa-v1.0-train.jsonl.gz

  
## Secondary task:
A simplified version of TyDi QA's primary task. If you are constrained by computational resources or are tied to existing code that processes the SQuAD format, the gold passage task may be a better way for you to get started.
Lack core challenges of TyDi QA, e.g.no long articles, no unanswerable questions.
Can generally be swapped into any code that accepts SQuAD 1.1 JSON inputs with just a few line modified. Example instruction to do so provided in https://github.com/google-research-datasets/tydiqa/blob/master/gold_passage_baseline
 
- **Gold passage task (GoldP):**
  Given a passage that is guaranteed to contain the answer, predict the single contiguous span of characters that answers the question. This is more similar to existing reading comprehension datasets (as opposed to the information-seeking process of primary tasks). This task is constructed with two goals in mind: (1) more directly comparing with prior work and (2) providing a simplified way for researchers to use TyDi QA by providing compatibility with existing code for SQuAD 1.1, XQuAD, and MLQA. Toward these goals, the gold passage task differs from the primary task in several ways:
  - only the gold answer passage is provided rather than the entire Wikipedia article;
  - unanswerable questions have been discarded, similar to MLQA and XQuAD
  - we evaluate with the SQuAD 1.1 metrics like XQuAD; and
  - Thai and Japanese are removed since the lack of whitespace breaks some tools.

### Evaluation:
re-use the existing SQuAD 1.1 evaluation code.

### Download:
The gold passage training set is about 50MB and the dev set is about 10MB. The extra tarball for the dev set contains JSON files that are split along language boundaries; these are used for evaluation while the single large JSON dev file makes it easier to run inference on the entire dev set in a single invocation.
</br>
https://storage.googleapis.com/tydiqa/v1.1/tydiqa-goldp-v1.1-dev.json
https://storage.googleapis.com/tydiqa/v1.1/tydiqa-goldp-v1.1-train.json
https://storage.googleapis.com/tydiqa/v1.1/tydiqa-goldp-v1.1-dev.tgz


# Example
### Example 1 (Minimal Span)
An English example from TYDI QA. The answer passage must be selected from a list of pas- sages in a Wikipedia article while the minimal answer is some span of bytes in the article (bold).
</br>
</br>
**QUESTION:** What are the types of matter? 
</br>
</br>
**ANSWER:** . . . Four states of matter are observable in everyday life: **solid, liquid, gas, and plasma**. Many other states are known to exist, such as glass or liquid crystal. . .
</br>
</br>
</br>
### Other examples:
![alt text](https://github.com/jessieGeng/NLPstorage/blob/main/image.jpg?raw=true)


## Online Repository link
Website: https://ai.google.com/research/tydiqa/dataset

Github: https://github.com/google-research-datasets/tydiqa/tree/master

## Paper
https://storage.cloud.google.com/tydiqa/tydiqa.pdf

## Contact
tydiqa@google.com


