import logging
import os
import sys
import torch

from arguments import ModelArguments, DataArguments, TrainerArguments
from dataset import *
from model import *
from trainer import *
from answerer import *

from transformers import AutoConfig, AutoTokenizer, HfArgumentParser

logger = logging.getLogger(__name__)


def main():
    parser = HfArgumentParser((ModelArguments, DataArguments, TrainerArguments))
    model_args, data_args, trainer_args = parser.parse_args_into_dataclasses()
    model_args: ModelArguments
    data_args: DataArguments
    trainer_args: TrainerArguments
    
    device = "cuda:0"
    qa_model = QASystemLoad(model_args, data_args).to(device)
    ranking_model = RankingModel(model_args, data_args)
    answerer = Answerer(qa_model, ranking_model)
    
    parsed_data_ls = answerer.parse_file(data_args.filename)
    
    
    output_path = f'{data_args.main_path}/answer_output.txt'
    with open(output_path, 'w') as output:
        for data in parsed_data_ls:
            question = data['question']
            context = data['context']
            #for question in questions:
            answer = answerer.single_answer(context, question)
            output.write(answer+"\n")
    


if __name__ == "__main__":
    main()
