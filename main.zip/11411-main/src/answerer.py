import re
import numpy as np

class Answerer():
    def __init__(self, qa_model, ranking_model):
        self.qa_model = qa_model
        self.ranking_model = ranking_model
    
    def chunk_context(self,context, max_len=300, min_len=150):
        sentences = re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', context)  # Splitting into sentences
        chunks = []
        current_chunk = ""

        for sentence in sentences:
            if len(current_chunk.split()) + len(sentence.split()) <= max_len:
                current_chunk += sentence + " "
            else:
                chunks.append(current_chunk.strip())
                current_chunk = sentence + " "

        if current_chunk:
            if len(current_chunk.split()) < min_len:
                chunks[-1] = chunks[-1]+current_chunk
            else:
                chunks.append(current_chunk.strip())

        return chunks
    
    def parse_file(self, file_path):
        
        parsed_data = []

        with open(file_path, 'r') as file:
            for line in file:
                line = line.strip()

                parts = line.split("context:")
                question = parts[0].replace("question:", "").strip()
                context_answer = parts[1].strip().split("answer:")
                context = context_answer[0].strip()
                answer = context_answer[1].strip()

                entry = {"question": question, "context": context, "answer": answer}
                parsed_data.append(entry)
        #print(parsed_data)
        return parsed_data

    
    def dot_score(self, question, context):
        question_embedding = self.ranking_model.embedding(question)
        context_embedding = self.ranking_model.embedding(context)
        score = np.dot(question_embedding, context_embedding)
        return score
        
    
    def single_answer(self, context, question):
        max_score = -1
        best_ans = None
        tokens = context.split()
        print(len(tokens))
        if len(tokens) >= 300:
            #print("context length > 512\n")
            #print("context:", context)
            #print()
            chunks = self.chunk_context(context)
            best_chunk = None
            for chunk in chunks:
                score = self.dot_score(question, chunk)
                #print("chunk:",chunk)
                #print()
                #print("score:", score)
                #print()
                if (best_chunk == None) or (score > max_score):
                    max_score = score
                    best_chunk = chunk
            #print("best_chunk:", best_chunk)
            #print()
            best_ans = self.qa_model.question_answer(question, best_chunk)
        else:
            best_ans = self.qa_model.question_answer(question, context)
        return best_ans
            

    
        
    