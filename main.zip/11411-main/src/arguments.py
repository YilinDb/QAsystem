from dataclasses import dataclass, field
from typing import Optional, List
from transformers import TrainingArguments, Seq2SeqTrainingArguments

@dataclass
class ModelArguments:
    model: str = field(
        default = "t5-base",
        metadata={"help": "path to pretrained model or model id"}
    )
    ranking_model: Optional[str] = field(
        default =  "t5-base",
        metadata={"help": "path to ranking model"}
    )
    untie_encoder: bool = field(
        default=False,
        metadata={"help": "no weight sharing between qry passage encoders"}
    )
    feature: str = field(
        default="last_hidden_state",
        metadata={"help": "What feature to be extracted from the HF PLM"}
    )
    pooling: str = field(
        default="first",
        metadata={"help": "How to pool the features from the HF PLM"}
    )

    # out projection
    add_linear_head: bool = field(default=False)
    projection_in_dim: int = field(default=768)
    projection_out_dim: int = field(default=768)

    # for Jax training
    dtype: Optional[str] = field(
        default="float32",
        metadata={
            "help": "Floating-point format in which the model weights should be initialized and trained. Choose one "
                    "of `[float32, float16, bfloat16]`. "
        },
    )
    encoder_only: bool = field(
        default=False,
        metadata={"help": "Whether to only use the encoder of T5"}
    )
    pos_token: Optional[str] = field(
        default=None,
        metadata={"help": "Token that indicates a relevant document"}
    )
    neg_token: Optional[str] = field(
        default=None,
        metadata={"help": "Token that indicates a irrelevant document"}
    )

    normalize: bool = field(
        default=False,
        metadata={"help": "Whether to normalize the embeddings"}
    )
    param_efficient_method: Optional[str] = field(
        default=None,
        metadata={"help": "Param efficient method used in model training"}
    )

    
    
@dataclass
class DataArguments:
    if_download: bool = field(
        default=False, metadata={"help": "if downloading the dataset from 'datasets'"}
    )
    
    path: str = field(
        default=None, metadata={"help": "path to dataset online"}
    )
    
    train_path: str = field(
        default=None, metadata={"help": "Path to single train file"}
    )
    
    eval_path: str = field(
        default=None, metadata={"help": "Path to eval file"}
    )
    
    answer_len: int = field(
        default=128,
        metadata={
            "help": "the length of tokenized answer"
        }
    )
    
    question_len: int = field(
        default=128,
        metadata={
            "help": "the length of tokenized question"
        }
    )
    
    context_len: int = field(
        default=128,
        metadata={
            "help": "the length of tokenized context"
        }
    )
    
    main_path: str = field(
        default=None,
        metadata={
            "help": "main path (EX_NAME)"
        }
    )
    
    question_num: int = field(
        default=0, 
        metadata={
            "help": "number of questions generated per context"
        }
    )
    
    filename: str = field(
        default=None, 
        metadata={
            "help": "the file of contexts to generate questions from"
        }
    )
    
@dataclass
class TrainerArguments(TrainingArguments):
    pass


@dataclass
class SystemArguments(TrainingArguments):
    qg_model: str = field(
        default = "t5-base",
        metadata={"help": "path to pretrained qg model or model id"}
    )
    
    qg_tokenizer: str = field(
        default = 't5-large',
        metadata={"help": "path to pretrained qg model or model id"}
    )
    
    qa_model: str = field(
        default = "t5-base",
        metadata={"help": "path to pretrained qa model or model id"}
    )
    
    qa_tokenizer: str = field(
        default = 't5-large',
        metadata={"help": "path to pretrained qg model or model id"}
    )
    
    few_shot: str = field(
        default = "mistralai/Mistral-7B-Instruct-v0.1",
        metadata={"help": "path to the few shot model or model id"}
    )
    
    ranking_model: Optional[str] = field(
        default =  "t5-base",
        metadata={"help": "path to ranking model"}
    )
    
    if_download_dataset: bool = field(
        default=False, metadata={"help": "if downloading the dataset from 'datasets'"}
    )
    
    dataset_path: str = field(
        default=None, metadata={"help": "path to dataset online"}
    )
    
    main_path: str = field(
        default=None,
        metadata={
            "help": "main path (EX_NAME)"
        }
    )
    
    question_num: int = field(
        default=0, 
        metadata={
            "help": "number of questions generated per context"
        }
    )
    
    filename: str = field(
        default=None, 
        metadata={
            "help": "the file of contexts to generate questions from"
        }
    )
    
    answer_len: int = field(
        default=128,
        metadata={
            "help": "the length of tokenized answer"
        }
    )
    
    question_len: int = field(
        default=128,
        metadata={
            "help": "the length of tokenized question"
        }
    )
    
    context_len: int = field(
        default=128,
        metadata={
            "help": "the length of tokenized context"
        }
    )
    
    file_style: bool = field(
        default=False,
        metadata={
            "help": "does the input data file has indicators like 'question:'?"
        }
    )
    
    