# How To Use QADataset
## Arguments
1. DataArgument:
   if_download: download online?
   path: the name of the online dataset (!!!use only when if_download is true, otherwise it wont work!!!)
   train_path: path to the training dataset (!!!use only when if_download is false, which means to load the dataset locally!!!)
   eval_path: path to the evaluation dataset (!!!use only when if_download is false, which means to load the dataset locally!!!)
   answer_len: how many tokens can answers have
   question_len: how many tokens can questions have
   context_len: how many tokens can contexts have
   
2. !!!NOT FORGET TO SET if_train IN question_answer.py NOT IN SCRIPT!!!

## How to Load Different Datasets
1. Load Online Squad Dataset <br>
   Indicate you want to download from the package by "if_download = TRUE" <br>
   Enter the name of the dataset by "path = NAME OF THE DATASET YOU WANT (STR)" <br>
   Indicate if it is a training set by "data_args.if_train = TRUE/FALSE (BOOL)" (False means it is a eval dataset) <br>
   OR JUST RUN THE qa.sh SCRIPT
   
2. Load LOCAL Squad Dataset Preprocessed to Have Shorter Contexts <br>
   first you need to run squad_preprocess.py in the folder called "dataset" <br>
   you should see two .json files <br>
   RUN qa_short_context.sh <br>

## Collator Outputs
1. QACollator (still working on it) <br>
   output["question"] <br>
   output["context"]: <br>
   output["answer"]: <br>
   
2. QACollatorLM <br>
   output["raw_answer"]: list of strings <br>
   outptut["question+context"] with keys("input_ids" and "attention_mask"): a dictionary that contains: 1. a tensor for all tokens of question+context 2. a tensor for all attention masks of question+context <br>
   outptut["answer"]: with keys("input_ids" and "attention_mask"): a dictionary that contains: 1. a tensor for all tokens of answer 2. a tensor for all attention masks of answer <br>
   
   TENSORS HAVE A SHAPE OF Batch x Number of Tokens <br>
