from dataclasses import dataclass
from typing import Any, Dict, List

import torch
from transformers import DataCollatorWithPadding, DefaultDataCollator


@dataclass
class QACollator(DataCollatorWithPadding):
    def __init__(self, tokenizer, data_args) -> None:
        super().__init__(tokenizer=tokenizer)
        self.max_p_len = data_args.context_len
        self.max_q_len = data_args.question_len
        self.max_a_len = data_args.answer_len
        self.tokenizer = tokenizer

    def __call__(self, features: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        d = dict()
        d["question+context"] = []
        d["answer"] = []
        d["raw_answer"] = []
        for i, e in enumerate(features):
            d["question+context"].append(
                self.tokenizer(
                    "question: "+e["question"]+" context: "+e["context"],
                    padding="max_length",
                    max_length=self.max_p_len,
                    truncation=True,
                    return_tensors="pt",
                )
            )
            d["answer"].append(
                self.tokenizer(
                    e["answer"][0],
                    padding="max_length",
                    max_length=self.max_a_len,
                    truncation=True,
                    return_tensors="pt",
                )
            )
            d["raw_answer"].append(e["answer"][0])
        
        question_context = {}

        working_list_qc_ids = []
        working_list_qc_masks = []
        for item in d["question+context"]:
            working_list_qc_ids.append(item["input_ids"])
            working_list_qc_masks.append(item["attention_mask"])
        
        question_context["input_ids"] = working_list_qc_ids
        question_context["attention_mask"] = working_list_qc_masks
        
        question_context["input_ids"] = torch.cat(question_context["input_ids"], dim=0)
        question_context["attention_mask"] = torch.cat(question_context["attention_mask"], dim=0)
        
        d["question+context"] = question_context

        answer = {}
        
        working_list_a_ids = []
        working_list_a_masks = []
        for item in d["answer"]:
            working_list_a_ids.append(item["input_ids"])
            working_list_a_masks.append(item["attention_mask"])
        
        answer["input_ids"] = working_list_a_ids
        answer["attention_mask"] = working_list_a_masks
        
        answer["input_ids"] = torch.cat(answer["input_ids"], dim=0)
        answer["attention_mask"] = torch.cat(answer["attention_mask"], dim=0)
        
        d["answer"] = answer
        
        # print(batch)
        # print(batch["input_ids"])
        # print(batch["attention_mask"])
        # print(batch["token_type_ids"])
        # print(batch["start_positions"])
        # print(batch["end_positions"])
        return d
    
@dataclass
class BENCHMARK_MRM_QACollator(DataCollatorWithPadding):
    def __init__(self, tokenizer, data_args) -> None:
        super().__init__(tokenizer=tokenizer)
        self.max_p_len = data_args.context_len
        self.max_q_len = data_args.question_len
        self.max_a_len = data_args.answer_len
        self.tokenizer = tokenizer

    def __call__(self, features: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        d = dict()
        d["question+context"] = []
        d["answer"] = []
        d["raw_answer"] = []
        for i, e in enumerate(features):
            d["question+context"].append(
                self.tokenizer(
                    "question: {fquestion}  context: {fcontext}".format(fquestion = e["question"], fcontext = e["context"]),
                    padding="max_length",
                    max_length=self.max_p_len,
                    truncation=True,
                    return_tensors="pt",
                )
            )
            d["answer"].append(
                self.tokenizer(
                    e["answer"][0],
                    padding="max_length",
                    max_length=self.max_a_len,
                    truncation=True,
                    return_tensors="pt",
                )
            )
            d["raw_answer"].append(e["answer"][0])
        
        question_context = {}

        working_list_qc_ids = []
        working_list_qc_masks = []
        for item in d["question+context"]:
            working_list_qc_ids.append(item["input_ids"])
            working_list_qc_masks.append(item["attention_mask"])
        
        question_context["input_ids"] = working_list_qc_ids
        question_context["attention_mask"] = working_list_qc_masks
        
        question_context["input_ids"] = torch.cat(question_context["input_ids"], dim=0)
        question_context["attention_mask"] = torch.cat(question_context["attention_mask"], dim=0)
        
        d["question+context"] = question_context

        answer = {}
        
        working_list_a_ids = []
        working_list_a_masks = []
        for item in d["answer"]:
            working_list_a_ids.append(item["input_ids"])
            working_list_a_masks.append(item["attention_mask"])
        
        answer["input_ids"] = working_list_a_ids
        answer["attention_mask"] = working_list_a_masks
        
        answer["input_ids"] = torch.cat(answer["input_ids"], dim=0)
        answer["attention_mask"] = torch.cat(answer["attention_mask"], dim=0)
        
        d["answer"] = answer
        
        # print(batch)
        # print(batch["input_ids"])
        # print(batch["attention_mask"])
        # print(batch["token_type_ids"])
        # print(batch["start_positions"])
        # print(batch["end_positions"])
        return d

@dataclass
class QACollatorGPT(DataCollatorWithPadding):
    def __init__(self, tokenizer, data_args) -> None:
        super().__init__(tokenizer=tokenizer)
        self.max_p_len = data_args.context_len
        self.max_q_len = data_args.question_len
        self.max_a_len = data_args.answer_len
        self.tokenizer = tokenizer

    def __call__(self, features: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        d = dict()
        d["question+context"] = []
        d["answer"] = []
        d["raw_answer"] = []
        for i, e in enumerate(features):
            d["question+context"].append(
                self.tokenizer(
                    "question: "+e["question"]+" context: "+e["context"]+" answer: ",
                    padding="max_length",
                    max_length=self.max_p_len,
                    truncation=True,
                    return_tensors="pt",
                )
            )
            d["answer"].append(
                self.tokenizer(
                    e["answer"][0],
                    padding="max_length",
                    max_length=self.max_a_len,
                    truncation=True,
                    return_tensors="pt",
                )
            )
            d["raw_answer"].append(e["answer"][0])
        
        question_context = {}

        working_list_qc_ids = []
        working_list_qc_masks = []
        for item in d["question+context"]:
            working_list_qc_ids.append(item["input_ids"])
            working_list_qc_masks.append(item["attention_mask"])
        
        question_context["input_ids"] = working_list_qc_ids
        question_context["attention_mask"] = working_list_qc_masks
        
        question_context["input_ids"] = torch.cat(question_context["input_ids"], dim=0)
        question_context["attention_mask"] = torch.cat(question_context["attention_mask"], dim=0)
        
        d["question+context"] = question_context

        answer = {}
        
        working_list_a_ids = []
        working_list_a_masks = []
        for item in d["answer"]:
            working_list_a_ids.append(item["input_ids"])
            working_list_a_masks.append(item["attention_mask"])
        
        answer["input_ids"] = working_list_a_ids
        answer["attention_mask"] = working_list_a_masks
        
        answer["input_ids"] = torch.cat(answer["input_ids"], dim=0)
        answer["attention_mask"] = torch.cat(answer["attention_mask"], dim=0)
        
        d["answer"] = answer
        
        # print(batch)
        # print(batch["input_ids"])
        # print(batch["attention_mask"])
        # print(batch["token_type_ids"])
        # print(batch["start_positions"])
        # print(batch["end_positions"])
        return d
    
@dataclass
class QGCollator(DataCollatorWithPadding):
    def __init__(self, tokenizer, data_args) -> None:
        super().__init__(tokenizer=tokenizer)
        self.max_p_len = data_args.context_len
        self.max_q_len = data_args.question_len
        self.max_a_len = data_args.answer_len
        self.tokenizer = tokenizer

    def __call__(self, features: List[Dict[str, Any]]) -> Dict[str, torch.Tensor]:
        d = dict()
        d["answer+context"] = []
        d["question"] = []
        d["raw_question"] = []
        for i, e in enumerate(features):
            d["answer+context"].append(
                self.tokenizer(
                    "answer: "+e["answer"][0]+" context: "+e["context"],
                    padding="max_length",
                    max_length=self.max_p_len,
                    truncation=True,
                    return_tensors="pt",
                )
            )
            d["question"].append(
                self.tokenizer(
                    e["question"],
                    padding="max_length",
                    max_length=self.max_q_len,
                    truncation=True,
                    return_tensors="pt",
                )
            )
            d["raw_question"].append(e["question"])

        answer_context = {}

        working_list_ac_ids = []
        working_list_ac_masks = []
        for item in d["answer+context"]:
            working_list_ac_ids.append(item["input_ids"])
            working_list_ac_masks.append(item["attention_mask"])
        
        answer_context["input_ids"] = working_list_ac_ids
        answer_context["attention_mask"] = working_list_ac_masks
        
        answer_context["input_ids"] = torch.cat(answer_context["input_ids"], dim=0)
        answer_context["attention_mask"] = torch.cat(answer_context["attention_mask"], dim=0)
        
        d["answer+context"] = answer_context

        question = {}
        
        working_list_q_ids = []
        working_list_q_masks = []
        for item in d["question"]:
            working_list_q_ids.append(item["input_ids"])
            working_list_q_masks.append(item["attention_mask"])
        
        question["input_ids"] = working_list_q_ids
        question["attention_mask"] = working_list_q_masks
        
        question["input_ids"] = torch.cat(question["input_ids"], dim=0)
        question["attention_mask"] = torch.cat(question["attention_mask"], dim=0)
        
        d["question"] = question

        return d
