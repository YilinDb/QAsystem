# install pytorch
# pip install datasets transformers

import json
from torch.utils.data import Dataset, DataLoader
from transformers import AutoTokenizer
from datasets import load_dataset, load_metric
from arguments import DataArguments

class QADataset(Dataset):
    def __init__(self, data_args, if_train) -> None:
        super().__init__()
        self.pack = []
        if data_args.if_download:
            if data_args.path == "squad_v2" or data_args.path == "squad":
                # load the data
                self.data = load_dataset(f"{data_args.path}")
                # load the part needed
                if if_train:
                    self.data = self.data["train"]
                else:
                    self.data = self.data["validation"]
                    
                for i in range(0, len(self.data)):
                    # skip cases without an answer
                    if self.data[i]["answers"]["text"] != []:
                        res = {}
                        res["question"] = self.data[i]["question"]                 
                        res["answer"] = self.data[i]["answers"]["text"]
                        res["context"] = self.data[i]["context"]

                        self.pack.append(res)
                        
            if data_args.path == "hotpot_qa":
                # load the data
                self.data = load_dataset(f"{data_args.path}", "fullwiki")
                # load the part needed
                if if_train:
                    self.data = self.data["train"]
                else:
                    self.data = self.data["validation"] # versus test?
                    
                for i in range(0, len(self.data)):
                    # skip cases without an answer
                    if self.data[i]["answer"] != "":
                        res = {}
                        res["question"] = self.data[i]["question"]                 
                        res["answer"] = [self.data[i]["answer"]]
                        context = ""
                        for j in range(len(self.data[i]["supporting_facts"]["title"])):
                            title = self.data[i]["supporting_facts"]["title"][j]
                            sentence = self.data[i]["supporting_facts"]["sent_id"][j]
                            for k in range(len(self.data[i]["context"]["title"])):
                                if title == self.data[i]["context"]["title"][k]:
                                    article_index = k
                            context = context + " " + self.data[i]["context"]["sentences"][article_index][sentence]
                        
                        context = context.strip()
                        res["context"] = context

                        self.pack.append(res)
            
        else:
            # choose which part to load
            if if_train:
                with open(data_args.train_path, 'r') as json_file:
                    self.data = json.load(json_file)
            else:
                with open(data_args.eval_path, 'r') as json_file:
                    self.data = json.load(json_file)
            
            # load the data
            for i in range(0, len(self.data)):
                # skip cases without an answer
                if self.data[i]["answer"] != []:
                    res = {}
                    res["question"] = self.data[i]["question"]                 
                    res["answer"] = [self.data[i]["answer"]]
                    res["context"] = self.data[i]["context"]
                    
                    self.pack.append(res)
                    
        print("Dataset loaded, size is ", len(self.pack))
                                
        del self.data
            

    def __len__(self):
        return len(self.pack)
    
    def __getitem__(self, index) -> any:   
        return self.pack[index]


class QGDataset(Dataset):
    def __init__(self, data_args, if_train) -> None:
        super().__init__()
        self.pack = []
        if data_args.if_download:
            if data_args.path == "squad_v2" or data_args.path == "squad":
                # load the data
                self.data = load_dataset(f"{data_args.path}")
                # load the part needed
                if if_train:
                    self.data = self.data["train"]
                else:
                    self.data = self.data["validation"]
                    
                for i in range(0, len(self.data)):
                    # skip cases without an answer
                    if self.data[i]["answers"]["text"] != []:
                        res = {}
                        res["question"] = self.data[i]["question"]                 
                        res["answer"] = self.data[i]["answers"]["text"]
                        res["context"] = self.data[i]["context"]

                        self.pack.append(res)
                        
            if data_args.path == "hotpot_qa":
                # load the data
                self.data = load_dataset(f"{data_args.path}", "fullwiki")
                # load the part needed
                if if_train:
                    self.data = self.data["train"]
                else:
                    self.data = self.data["validation"] # versus test?
                    
                for i in range(0, len(self.data)):
                    # skip cases without an answer
                    if self.data[i]["answer"] != "":
                        res = {}
                        res["question"] = self.data[i]["question"]                 
                        res["answer"] = [self.data[i]["answer"]]
                        context = ""
                        for j in range(len(self.data[i]["supporting_facts"]["title"])):
                            title = self.data[i]["supporting_facts"]["title"][j]
                            sentence = self.data[i]["supporting_facts"]["sent_id"][j]
                            for k in range(len(self.data[i]["context"]["title"])):
                                if title == self.data[i]["context"]["title"][k]:
                                    article_index = k
                            context = context + " " + self.data[i]["context"]["sentences"][article_index][sentence]
                        
                        context = context.strip()
                        res["context"] = context

                        self.pack.append(res)
            
        else:
            # choose which part to load
            if if_train:
                with open(data_args.train_path, 'r') as json_file:
                    self.data = json.load(json_file)
            else:
                with open(data_args.eval_path, 'r') as json_file:
                    self.data = json.load(json_file)
            
            # load the data
            for i in range(0, len(self.data)):
                # skip cases without an answer
                if self.data[i]["answer"] != []:
                    res = {}
                    res["question"] = self.data[i]["question"]                 
                    res["answer"] = [self.data[i]["answer"]]
                    res["context"] = self.data[i]["context"]
                    
                    self.pack.append(res)
                    
        print("Dataset loaded, size is ", len(self.pack))
                                
        del self.data
            

    def __len__(self):
        return len(self.pack)
    
    def __getitem__(self, index) -> any:   
        return self.pack[index]
