from datasets import load_dataset
import random
import time
from datetime import datetime

#import some config
number = 5
print_path = "./"
_type = "answer_long"
min_length = None

corpus = load_dataset(f"squad_v2")["validation"]
corpus_len = len(corpus)

ret = list()
while len(ret) < number:
    ran = random.randint(0, corpus_len)
    if _type == "only_context":
        ret.append(corpus[ran]["context"])
    elif _type == "few-shot":
        pass
    elif _type == "full":
        imp = "question: " + corpus[ran]["question"] + " "
        imp += "context: " + corpus[ran]["context"] + " "
        imp += "answer: " + corpus[ran]["answers"]["text"][0]
        ret.append(imp)
    elif _type == "answer_long":
        if len(corpus[ran]["answers"]["text"]) == 0:
            continue
        # print(corpus[ran]["answers"]["answer_start"])
        answer_start = corpus[ran]["answers"]["answer_start"][0]
        if answer_start < 2000:
            continue
        imp = "question: " + corpus[ran]["question"] + " "
        imp += "context: " + corpus[ran]["context"] + " "
        imp += "answer: " + corpus[ran]["answers"]["text"][0]
        ret.append(imp)
        print(corpus[ran]["answers"]["answer_start"])
        

current_time = datetime.now()
formatted_time = current_time.strftime("%H:%M:%S")
with open("/home/ec2-user/11411/src/dataset/{}-{}.txt".format(_type, str(formatted_time)), 'w+') as f:
    for i, ele in enumerate(ret):
        f.write(ele + '\n')