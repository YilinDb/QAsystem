from datasets import load_dataset
import json

squad = load_dataset("squad_v2")

squad_train = squad["train"]

squad_validation = squad["validation"]

before_answer_len_max = 256 # 256 characters

result_train = []
result_validation = []

for entry in squad_train:
    if entry["answers"]["text"] != []:
        answer_start = int(entry["answers"]["answer_start"][0])
        context_start = 0
        i = answer_start
        if entry["context"][i] != "!" and entry["context"][i] != "?" and entry["context"][i] != ".":
            while i >= 0 and (answer_start - i) <= before_answer_len_max:
                # if we reached the start of the full context
                if i == 0:
                    context_start = i
                # if we reached the end of a sentence. Case 1 without ""
                if entry["context"][i] == "!" or entry["context"][i] == "?" or entry["context"][i] == ".":
                    context_start = i+2
                # case 2 with ""
                if entry["context"][i] == "\"" or entry["context"][i] == "\'":
                    if i != 0:
                        if entry["context"][i-1] == "!" or entry["context"][i-1] == "?" or entry["context"][i-1] == ".":
                            context_start = i+2        
                i -= 1
        
        d = {}
        d["context"] = entry["context"][context_start:]
        d["answer"] = entry["answers"]["text"][0]
        d["question"] = entry["question"]
        d["answer_start"] = answer_start - context_start


        if d["answer_start"] <= before_answer_len_max:
            result_train.append(d) 
            
for entry in squad_validation:
    if entry["answers"]["text"] != []:
        answer_start = int(entry["answers"]["answer_start"][0])
        context_start = 0
        i = answer_start
        if entry["context"][i] != "!" and entry["context"][i] != "?" and entry["context"][i] != ".":
            while i >= 0 and (answer_start - i) <= before_answer_len_max:
                # if we reached the start of the full context
                if i == 0:
                    context_start = i
                # if we reached the end of a sentence. Case 1 without ""
                if entry["context"][i] == "!" or entry["context"][i] == "?" or entry["context"][i] == ".":
                    context_start = i+2
                # case 2 with ""
                if entry["context"][i] == "\"" or entry["context"][i] == "\'":
                    if i != 0:
                        if entry["context"][i-1] == "!" or entry["context"][i-1] == "?" or entry["context"][i-1] == ".":
                            context_start = i+2        
                i -= 1
        
        d = {}
        d["context"] = entry["context"][context_start:]
        d["answer"] = entry["answers"]["text"][0]
        d["question"] = entry["question"]
        d["answer_start"] = answer_start - context_start
        
        if d["answer_start"] <= before_answer_len_max:
            result_validation.append(d) 

print("all instances with a too longer context or without an answer are excluded")

print(f"length of the training dataset: {len(result_train)}")

print(f"length of the validation dataset: {len(result_validation)}")

with open("squad_train.json", "w") as outfile: 
    json.dump(result_train, outfile)

with open("squad_validation.json", "w") as outfile: 
    json.dump(result_validation, outfile)
