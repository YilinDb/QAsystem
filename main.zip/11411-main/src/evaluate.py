from metrics import *
import sys

def main():
    if (len(sys.argv) > 1):
        filename = sys.argv[1]
        print("Evaluating file: ", filename)
    else:
        print("Please provide a file path as a command line argument.")
        exit()

    gt = []
    pred = []
    with open(filename, 'r') as f:
        lines = f.readlines()
        for i in range(len(lines)):
            if i % 2 == 0:
                gt.append(lines[i].removeprefix('generated:  '))
            else:
                pred.append(lines[i].removeprefix('ground truth: '))

    print('F1 score: ', f1_list(pred, gt))
    print('EM score: ', em_list(pred, gt))
    print('BLEU score: ', bleu_list(pred, gt))
    print('ROUGE score: ', rouge_list(pred, gt))
    print('METEOR score: ', meteor_list(pred, gt))
    print('chrf score: ', chrf_list(pred, gt))
    
    
    
if __name__ == '__main__':
    main()