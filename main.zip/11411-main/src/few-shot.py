from datasets import load_dataset
from random import randint
from transformers import AutoModelForCausalLM, AutoTokenizer

import os

def set_affinity(num_cores):
    pid = os.getpid()
    os.sched_setaffinity(pid, set(range(num_cores)))

set_affinity(2)


class finetune_data_generator:
    def __init__(self):
        self.validation = load_dataset(f"squad_v2")["validation"]
        self.train = load_dataset(f"squad_v2")["train"]

    def get_finetune_data(self, number):
        concat = ""
        for i in range(number):
            random = randint(0, len(self.train))
            concat += "example " + str(i) + ": "
            concat += "question: " + self.train[i]["question"] + " "
            concat += "context: " + self.train[i]["context"] + " "
            concat += "answer: " + self.train[i]["answers"]["text"][0] + "\n"

        with open('./long.txt') as f:
            qc = f.read()
            concat += qc + '\n'
        concat += "Answer should be within 15 words: "
        return concat, "women retire at age 60 and men at 65"

class finetune_question_generator:
    def __init__(self):
        self.validation = load_dataset(f"squad_v2")["validation"]
        self.train = load_dataset(f"squad_v2")["train"]

    def get_finetune_data(self, number):
        concat = ""
        for i in range(number):
            random = randint(0, len(self.train))
            concat += "example " + str(i) + ": "
            concat += "context: " + self.train[i]["context"] + " "
            concat += "question: " + self.train[i]["question"] + " "
            concat += "\n"
            # concat += "answer: " + self.train[i]["answers"]["text"][0] + "\n"

        with open('./long.txt') as f:
            qc = f.read()
            concat += qc + '\n'
        concat += "Ask 5 easiest questions related to the last context that could be answered directly with context message: "
        return concat, "women retire at age 60 and men at 65"

def main():
    generator = finetune_data_generator()
    concat, answer = generator.get_finetune_data(2)
    device = "cuda:0" # the device to load the model onto

    model = AutoModelForCausalLM.from_pretrained("mistralai/Mistral-7B-Instruct-v0.1")
    tokenizer = AutoTokenizer.from_pretrained("mistralai/Mistral-7B-Instruct-v0.1")

    encodeds = tokenizer.apply_chat_template([{"role": "user", "content": "{}".format(concat)},], return_tensors="pt")
    # print(encodeds.shape)

    model_inputs = encodeds.to(device)
    model.to(device)

    generated_ids = model.generate(model_inputs, max_new_tokens=1000, do_sample=True)
    decoded = tokenizer.batch_decode(generated_ids)
    print(decoded[0])



if __name__ == '__main__':
    main()
