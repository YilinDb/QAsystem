from nltk.translate.meteor_score import meteor_score
from nltk.translate.bleu_score import corpus_bleu,sentence_bleu
import re
import string
import rouge
from rouge import Rouge
from collections import Counter
from datasets import load_metric

def normalize(s):
    #Lower text and remove punctuation, articles and extra whitespace.
    lower = s.lower()
    
    exclude = set(string.punctuation)
    remove_punc = ''.join(ch for ch in lower if ch not in exclude)
    
    remove_articles = re.sub(r'\b(a|an|the)\b', ' ', remove_punc)
    
    white_space_fix = ' '.join(remove_articles.split())
    
    return white_space_fix

def f1_score(prediction, ground_truth):

    prediction_tokens = normalize(prediction).split()
    ground_truth_tokens = normalize(ground_truth).split()
    common = Counter(prediction_tokens) & Counter(ground_truth_tokens)
    num_same = sum(common.values())
    if num_same == 0:
        return 0
    precision = 1.0 * num_same / len(prediction_tokens)
    recall = 1.0 * num_same / len(ground_truth_tokens)
    f1 = (2 * precision * recall) / (precision + recall)
    return f1
    
def f1_list(predictions,ground_truths):
    all_f1 = []
    for prediction, ground_truth in zip(predictions,ground_truths):
        if (prediction is None) or (prediction.strip() == "") or (ground_truth is None) or (ground_truth.strip() == ""):
            print("Problematic Rouge Prediction:", prediction)
            print("Problematic Rouge Reference:", ground_truth)
            print()
            continue
        f1 = f1_score(prediction,ground_truth)
        all_f1.append(f1)
    res = sum(all_f1)/len(all_f1)
    return res

def exact_match_score(prediction, ground_truth):
    return (normalize(prediction) == normalize(ground_truth))

def em_list(predictions, ground_truths):
    all_em = []
    for prediction, ground_truth in zip(predictions,ground_truths):
        if (prediction is None) or (prediction.strip() == "") or (ground_truth is None) or (ground_truth.strip() == ""):
            print("Problematic Rouge Prediction:", prediction)
            print("Problematic Rouge Reference:", ground_truth)
            print()
            continue
        em_score = exact_match_score(prediction,ground_truth)
        all_em.append(em_score)
    res = sum(all_em)/len(all_em)
    return res
    

def bleu(prediction, ground_truth):
    prediction_tokens = prediction.split()
    ground_truth_tokens = [ground_truth.split()]
    bleu_score = sentence_bleu(ground_truth_tokens, prediction_tokens)   
    return bleu_score
    
def bleu_list(prediction, ground_truth):
    refs = [[ref.split()] for ref in ground_truth]
    preds = [hyp.split() for hyp in prediction]
    bleu_score = corpus_bleu(refs, preds)   
    return bleu_score
    
def rouge_list(predictions, ground_truths):
    rouge = Rouge()
    total_scores = {
    'rouge-1': {'f': 0.0, 'p': 0.0, 'r': 0.0},
    'rouge-2': {'f': 0.0, 'p': 0.0, 'r': 0.0},
    'rouge-l': {'f': 0.0, 'p': 0.0, 'r': 0.0}
    }
    for prediction,ground_truth in zip(predictions, ground_truths):
        if (prediction is None) or (prediction.strip() == "") or (ground_truth is None) or (ground_truth.strip() == ""):
            print("Problematic Rouge Prediction:", prediction)
            print("Problematic Rouge Reference:", ground_truth)
            print()
            continue
            
        scores = rouge.get_scores(prediction, ground_truth)[0]

        # Accumulate scores
        for metric in total_scores.keys():
            for score_type in ['f', 'p', 'r']:
                total_scores[metric][score_type] += scores[metric][score_type]
        
    num_pairs = len(predictions)
    average_scores = {metric: {score_type: total_scores[metric][score_type] / num_pairs for score_type in ['f', 'p', 'r']} for metric in total_scores.keys()}

    return average_scores
    
def meteor(prediction, ground_truth):
    prediction_tokens = normalize(prediction).split()
    ground_truth_tokens = normalize(ground_truth).split()
    score = meteor_score([ground_truth_tokens], prediction_tokens)
    return score
    
def meteor_list(predictions, ground_truths):
    total_meteor_score = 0.0
    for prediction, ground_truth in zip(predictions, ground_truths):
        if (prediction is None) or (prediction.strip() == "") or (ground_truth is None) or (ground_truth.strip() == ""):
            print("Problematic Rouge Prediction:", prediction)
            print("Problematic Rouge Reference:", ground_truth)
            print()
            continue
        score = meteor(prediction, ground_truth)
        total_meteor_score += score

    num_pairs = len(predictions)
    average_meteor_score = total_meteor_score / num_pairs

    return average_meteor_score

def chrf_list(predictions, ground_truths):
    chrf = load_metric("chrf")
    total_chrf_score = 0.0
    for prediction, ground_truth in zip(predictions, ground_truths):
        if (prediction is None) or (prediction.strip() == "") or (ground_truth is None) or (ground_truth.strip() == ""):
            print("Problematic Rouge Prediction:", prediction)
            print("Problematic Rouge Reference:", ground_truth)
            print()
            continue
        score = chrf.compute(predictions=[prediction], references=[[ground_truth]], word_order = 2)["score"]
        total_chrf_score += score

    num_pairs = len(predictions)
    average_chrf_score = total_chrf_score / num_pairs

    return average_chrf_score