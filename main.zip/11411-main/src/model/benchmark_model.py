from transformers import AutoModelForSeq2SeqLM, AutoTokenizer, T5ForConditionalGeneration
import torch
from torch.nn import Module
from arguments import ModelArguments

class QABenchmarkModel(Module):
    def __init__(self, model_args, data_args, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.model = AutoModelForSeq2SeqLM.from_pretrained(model_args.model)
        self.tokenizer = AutoTokenizer.from_pretrained(model_args.model)
        self.max_p_len = data_args.context_len
        self.max_q_len = data_args.question_len
        self.max_a_len = data_args.answer_len
    
    def tokenize(self, text):
        return self.tokenizer(text, 
                    padding="max_length",
                    max_length=self.max_p_len,
                    truncation=True,
                    return_tensors="pt")

    # [param] answer
    # [param] context
    # [return] question
    @torch.no_grad()
    def question_answer(self, question : str, context : str) -> str:   
        input_text = "question: "+ question +" context: " +  context
        input_ids = self.tokenize(input_text)
        outputs = self.model.generate(input_ids=input_ids['input_ids'], attention_mask=input_ids['attention_mask'], max_new_tokens=self.max_a_len+self.max_q_len)
        answer = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        return answer

    @torch.no_grad()
    def evaluate(self, answer_and_context, attention_mask, labels):
        outputs = self.model(input_ids=answer_and_context, attention_mask=attention_mask, labels=labels)
        return outputs
    
    # [param] a batch of tokenization of answers and context
    # [param] a batch of attention mask
    # [param] a batch of labels
    # [return] outputs of the model, loss of the batch, questions of the batch
    @torch.no_grad()
    def batch_evaluate(self, batch_answer_and_context, attention_mask, labels):
        outputs = self.model(input_ids=batch_answer_and_context, attention_mask=attention_mask, labels=labels)
        questions = self.batch_question(batch_answer_and_context)
        return outputs, outputs.loss, questions

    # [param] a batch of tokenization of answers and context
    # [return] answers of the batch
    @torch.no_grad()
    def batch_question(self, batch_answer_and_context):
        outputs = self.model.generate(input_ids=batch_answer_and_context, max_new_tokens=self.max_a_len)
        questions = self.tokenizer.batch_decode(outputs, skip_special_tokens=True)
        return questions

    # [param] a batch of tokenization of answers and context
    # [param] a batch of attention mask
    # [param] a batch of labels
    # [return] the outputs of the model
    def forward(self, input_ids, attention_mask, labels):
        pass
    


class QGSystemLoad(Module):
    def __init__(self, model_args, data_args, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.model = T5ForConditionalGeneration.from_pretrained(model_args.model)
        self.tokenizer = AutoTokenizer.from_pretrained('t5-large')
        self.max_p_len = data_args.context_len
        self.max_q_len = data_args.question_len
        self.max_a_len = data_args.answer_len
    
    def tokenize(self, text):
        return self.tokenizer(text, 
                    padding="max_length",
                    max_length=self.max_p_len,
                    truncation=True,
                    return_tensors="pt")

    # [param] answer
    # [param] context
    # [return] question
    @torch.no_grad()
    def question_generate(self, answer : str, context : str) -> str:   
        input_text = "answer: "+ answer + " context: " + context
        input_ids = self.tokenize(input_text)
        outputs = self.model.generate(input_ids=input_ids['input_ids'].to('cuda:0'), attention_mask=input_ids['attention_mask'].to('cuda:0'), max_new_tokens=self.max_a_len+self.max_q_len)
        question = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        return question

    @torch.no_grad()
    def evaluate(self, answer_and_context, attention_mask, labels):
        outputs = self.model(input_ids=answer_and_context, attention_mask=attention_mask, labels=labels)
        return outputs
    
    # [param] a batch of tokenization of answers and context
    # [param] a batch of attention mask
    # [param] a batch of labels
    # [return] outputs of the model, loss of the batch, questions of the batch
    @torch.no_grad()
    def batch_evaluate(self, batch_answer_and_context, attention_mask, labels):
        outputs = self.model(input_ids=batch_answer_and_context, attention_mask=attention_mask, labels=labels)
        questions = self.batch_question(batch_answer_and_context)
        return outputs, outputs.loss, questions

    # [param] a batch of tokenization of answers and context
    # [return] answers of the batch
    @torch.no_grad()
    def batch_question(self, batch_answer_and_context):
        outputs = self.model.generate(input_ids=batch_answer_and_context, max_new_tokens=self.max_a_len+self.max_q_len)
        questions = self.tokenizer.batch_decode(outputs, skip_special_tokens=True)
        return questions

    # [param] a batch of tokenization of answers and context
    # [param] a batch of attention mask
    # [param] a batch of labels
    # [return] the outputs of the model
    def forward(self, input_ids, attention_mask, labels):
        outputs = self.model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
        return outputs
    
    def get_embedding(self, batch):
        return self.model.encoder.embed_tokens(batch)
    
    def save(self, path):
        self.model.save_pretrained(path)

    def load(self, path):
        self.model = T5ForConditionalGeneration.from_pretrained(path)



class QASystemLoad(Module):
    def __init__(self, model_args, data_args, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.model = T5ForConditionalGeneration.from_pretrained(model_args.model)
        self.tokenizer = AutoTokenizer.from_pretrained('t5-large')
        self.max_p_len = data_args.context_len
        self.max_q_len = data_args.question_len
        self.max_a_len = data_args.answer_len
    
    def tokenize(self, text):
        return self.tokenizer(text, 
                    padding="max_length",
                    max_length=self.max_p_len,
                    truncation=True,
                    return_tensors="pt")

    # [param] answer
    # [param] context
    # [return] question
    @torch.no_grad()
    def question_answer(self, question : str, context : str) -> str:   
        input_text = "question: "+ question +" context: " +  context
        input_ids = self.tokenize(input_text)
        outputs = self.model.generate(input_ids=input_ids['input_ids'].to('cuda:0'), attention_mask=input_ids['attention_mask'].to('cuda:0'), max_new_tokens=self.max_a_len+self.max_q_len)
        answer = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        return answer

    @torch.no_grad()
    def evaluate(self, answer_and_context, attention_mask, labels):
        outputs = self.model(input_ids=answer_and_context, attention_mask=attention_mask, labels=labels)
        return outputs
    
    # [param] a batch of tokenization of answers and context
    # [param] a batch of attention mask
    # [param] a batch of labels
    # [return] outputs of the model, loss of the batch, questions of the batch
    @torch.no_grad()
    def batch_evaluate(self, batch_answer_and_context, attention_mask, labels):
        outputs = self.model(input_ids=batch_answer_and_context, attention_mask=attention_mask, labels=labels)
        questions = self.batch_question(batch_answer_and_context)
        return outputs, outputs.loss, questions

    # [param] a batch of tokenization of answers and context
    # [return] answers of the batch
    @torch.no_grad()
    def batch_question(self, batch_answer_and_context):
        outputs = self.model.generate(input_ids=batch_answer_and_context, max_new_tokens=self.max_a_len+self.max_q_len)
        questions = self.tokenizer.batch_decode(outputs, skip_special_tokens=True)
        return questions

    # [param] a batch of tokenization of answers and context
    # [param] a batch of attention mask
    # [param] a batch of labels
    # [return] the outputs of the model
    def forward(self, input_ids, attention_mask, labels):
        outputs = self.model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
        return outputs
    
    def get_embedding(self, batch):
        return self.model.encoder.embed_tokens(batch)
    
    def save(self, path):
        self.model.save_pretrained(path)

    def load(self, path):
        self.model = T5ForConditionalGeneration.from_pretrained(path)
        
