from transformers import T5Tokenizer, T5Model, AutoTokenizer, AutoModel, AutoModelForCausalLM,T5ForConditionalGeneration, LlamaForCausalLM, GPT2Tokenizer, GPT2LMHeadModel
import torch
from torch.nn import Module
from arguments import ModelArguments


class QAModel(Module):
    def __init__(self, model_args, data_args, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.model = AutoModel.from_pretrained(model_args.model)
        self.tokenizer = AutoTokenizer.from_pretrained(model_args.model)
        self.max_p_len = data_args.context_len
        self.max_q_len = data_args.question_len
        self.max_a_len = data_args.answer_len

    # [param] question
    # [param] context
    # [return] answer
    @torch.no_grad()
    def question_answer(self, question : str, context : str) -> str:   
        input_question = self.tokenizer(question,
                                    padding="max_length",
                                    max_length=self.max_q_len,
                                    truncation=True,
                                    return_tensors="pt")
        input_context = self.tokenizer(context,
                                    padding="max_length",
                                    max_length=self.max_p_len,
                                    truncation=True,
                                    return_tensors="pt")
        outputs = self.evaluate(input_question, input_context)
        answer = self.tokenizer.decode(outputs)
        return answer
    
    # [param] tokenization of question
    # [param] tokenization of context
    # [return] outputs of the model
    @torch.no_grad()
    def evaluate(self, question, context):
        outputs = self.model(input_ids=context, decoder_input_ids=question)
        return outputs

    # [param] a batch of tokenization of questions
    # [param] a batch of tokenization of contexts
    # [return] a batch of answers
    @torch.no_grad()
    def batch_evaluate(self, batch_question, batch_context):
        outputs = self.model(input_ids=batch_context, decoder_input_ids=batch_question)
        logits  = outputs.last_hidden_state
        answers = self.tokenizer.batch_decode(logits)
        return answers

    # write the forward function with question and context as input and return the whole output of t5 model
    def forward(self, question, context):
        outputs = self.model(input_ids=context, decoder_input_ids=question)
        return outputs
    
    def save(self, path):
        self.model.save_pretrained(path)

    def load(self, path):
        self.model = AutoModel.from_pretrained(path)  

    def get_embedding(self, batch):
        return self.model.encoder.embed_tokens(batch)     

class QAModelT5ForConditionalGeneration(Module):
    def __init__(self, model_args, data_args, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.model = T5ForConditionalGeneration.from_pretrained(model_args.model)
        self.tokenizer = AutoTokenizer.from_pretrained(model_args.model)
        self.max_p_len = data_args.context_len
        self.max_q_len = data_args.question_len
        self.max_a_len = data_args.answer_len
    
    def tokenize(self, text):
        return self.tokenizer(text, 
                    padding="max_length",
                    max_length=self.max_p_len,
                    truncation=True,
                    return_tensors="pt")
    # [param] question
    # [param] context
    # [return] answer
    @torch.no_grad()
    def question_answer(self, question : str, context : str) -> str:   
        input_text = "question: "+ question +" context: " +  context
        input_ids = self.tokenize(input_text)
        outputs = self.model.generate(input_ids=input_ids['input_ids'], attention_mask=input_ids['attention_mask'], max_new_tokens=self.max_a_len+self.max_q_len)
        answer = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        return answer

    @torch.no_grad()
    def evaluate(self, question_and_context, attention_mask, labels):
        outputs = self.model(input_ids=question_and_context, attention_mask=attention_mask, labels=labels)
        return outputs
    
    # [param] a batch of tokenization of questions and context
    # [param] a batch of attention mask
    # [param] a batch of labels
    # [return] output of the model , loss of the batch, answers of the batch
    @torch.no_grad()
    def batch_evaluate(self, batch_question_and_context, attention_mask, labels):
        outputs = self.model(input_ids=batch_question_and_context, attention_mask=attention_mask, labels=labels)
        answers = self.batch_answer(batch_question_and_context)
        return outputs, outputs.loss, answers

    # [param] a batch of tokenization of questions and context
    # [return] answers of the batch
    @torch.no_grad()
    def batch_answer(self, batch_question_and_context):
        outputs = self.model.generate(input_ids=batch_question_and_context, max_new_tokens=self.max_a_len+self.max_q_len)
        answers = self.tokenizer.batch_decode(outputs, skip_special_tokens=True)
        return answers

    # [param] a batch of tokenization of questions and context
    # [param] a batch of attention mask
    # [param] a batch of labels
    # [return] the outputs of the model
    def forward(self, input_ids, attention_mask, labels):
        outputs = self.model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
        return outputs
    
    def get_embedding(self, batch):
        return self.model.encoder.embed_tokens(batch)
    
    def save(self, path):
        self.model.save_pretrained(path)

    def load(self, path):
        self.model = T5ForConditionalGeneration.from_pretrained(path)  

class QGModelT5ForConditionalGeneration(Module):
    def __init__(self, model_args, data_args, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.model = T5ForConditionalGeneration.from_pretrained(model_args.model)
        self.tokenizer = AutoTokenizer.from_pretrained(model_args.model)
        self.max_p_len = data_args.context_len
        self.max_q_len = data_args.question_len
        self.max_a_len = data_args.answer_len
    
    def tokenize(self, text):
        return self.tokenizer(text, 
                    padding="max_length",
                    max_length=self.max_p_len,
                    truncation=True,
                    return_tensors="pt")

    # [param] answer
    # [param] context
    # [return] question
    @torch.no_grad()
    def question_generate(self, answer : str, context : str) -> str:   
        input_text = "answer: "+ answer + " context: " + context
        input_ids = self.tokenize(input_text)
        outputs = self.model.generate(input_ids=input_ids['input_ids'], attention_mask=input_ids['attention_mask'], max_new_tokens=self.max_a_len+self.max_q_len)
        question = self.tokenizer.decode(outputs[0], skip_special_tokens=True)
        return question

    @torch.no_grad()
    def evaluate(self, answer_and_context, attention_mask, labels):
        outputs = self.model(input_ids=answer_and_context, attention_mask=attention_mask, labels=labels)
        return outputs
    
    # [param] a batch of tokenization of answers and context
    # [param] a batch of attention mask
    # [param] a batch of labels
    # [return] outputs of the model, loss of the batch, questions of the batch
    @torch.no_grad()
    def batch_evaluate(self, batch_answer_and_context, attention_mask, labels):
        outputs = self.model(input_ids=batch_answer_and_context, attention_mask=attention_mask, labels=labels)
        questions = self.batch_question(batch_answer_and_context)
        return outputs, outputs.loss, questions

    # [param] a batch of tokenization of answers and context
    # [return] answers of the batch
    @torch.no_grad()
    def batch_question(self, batch_answer_and_context):
        outputs = self.model.generate(input_ids=batch_answer_and_context, max_new_tokens=self.max_a_len+self.max_q_len)
        questions = self.tokenizer.batch_decode(outputs, skip_special_tokens=True)
        return questions

    # [param] a batch of tokenization of answers and context
    # [param] a batch of attention mask
    # [param] a batch of labels
    # [return] the outputs of the model
    def forward(self, input_ids, attention_mask, labels):
        outputs = self.model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
        return outputs
    
    def get_embedding(self, batch):
        return self.model.encoder.embed_tokens(batch)
    
    def save(self, path):
        self.model.save_pretrained(path)

    def load(self, path):
        self.model = T5ForConditionalGeneration.from_pretrained(path)


class QAModelShearedLLaMA(Module):
    def __init__(self, model_args, data_args, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        model_name = "princeton-nlp/Sheared-LLaMA-1.3B"
        self.tokenizer = AutoTokenizer.from_pretrained(model_name, use_fast=False)
        self.model = LlamaForCausalLM.from_pretrained(model_name, pad_token_id = self.tokenizer.eos_token_id)
        self.tokenizer.pad_token = self.tokenizer.eos_token
        self.max_p_len = data_args.context_len
        self.max_q_len = data_args.question_len
        self.max_a_len = data_args.answer_len

    
    def tokenize(self, text):
        return self.tokenizer(text, 
                    padding="max_length",
                    max_length=self.max_p_len,
                    truncation=True,
                    return_tensors="pt")
    # [param] question
    # [param] context
    # [return] answer
    @torch.no_grad()
    def question_answer(self, question : str, context : str) -> str:   
        input_text = "question: "+ question +" context: " +  context
        input_ids = self.tokenize(input_text)
        outputs = self.model.generate(input_ids=input_ids, max_new_tokens=self.max_a_len+self.max_q_len)
        answer = self.tokenizer.decode(outputs, skip_special_tokens=True)
        return answer

    @torch.no_grad()
    def evaluate(self, question_and_context, attention_mask, labels):
        outputs = self.model(input_ids=question_and_context, attention_mask=attention_mask, labels=labels)
        return outputs
    
    # [param] a batch of tokenization of questions and context
    # [param] a batch of attention mask
    # [param] a batch of labels
    # [return] output of the model , loss of the batch, answers of the batch
    @torch.no_grad()
    def batch_evaluate(self, batch_question_and_context, attention_mask, labels):
        outputs = self.model(input_ids=batch_question_and_context, attention_mask=attention_mask, labels=labels)
        answers = self.batch_answer(batch_question_and_context)
        return outputs, outputs.loss, answers

    # [param] a batch of tokenization of questions and context
    # [return] answers of the batch
    @torch.no_grad()
    def batch_answer(self, batch_question_and_context):
        outputs = self.model.generate(input_ids=batch_question_and_context, max_new_tokens=self.max_a_len+self.max_q_len)
        answers = self.tokenizer.batch_decode(outputs, skip_special_tokens=True)
        return answers

    # [param] a batch of tokenization of questions and context
    # [param] a batch of attention mask
    # [param] a batch of labels
    # [return] the outputs of the model
    def forward(self, input_ids, attention_mask, labels):
        outputs = self.model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
        return outputs
    
    def get_embedding(self, batch):
        return self.model.encoder.embed_tokens(batch)
    
    def save(self, path):
        self.model.save_pretrained(path)

    def load(self, path):
        self.model = AutoModelForCausalLM.from_pretrained(path)   


class QGModelShearedLLaMA(Module):
    def __init__(self, model_args, data_args, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        self.model = AutoModelForCausalLM.from_pretrained(model_args.model)
        self.tokenizer = AutoTokenizer.from_pretrained(model_args.model)
        self.tokenizer.add_special_tokens({'pad_token': '[PAD]'})
        self.max_p_len = data_args.context_len
        self.max_q_len = data_args.question_len
        self.max_a_len = data_args.answer_len
    
    def tokenize(self, text):
        return self.tokenizer(text, 
                    padding="max_length",
                    max_length=self.max_p_len,
                    truncation=True,
                    return_tensors="pt")

    # [param] answer
    # [param] context
    # [return] question
    @torch.no_grad()
    def question_generate(self, answer : str, context : str) -> str:   
        input_text = "answer: "+ answer + " context: " + context
        
        input_ids = self.tokenize(input_text)
        outputs = self.model.generate(input_ids=input_ids, max_new_tokens=self.max_a_len+self.max_q_len)
        question = self.tokenizer.decode(outputs, skip_special_tokens=True)
        return question

    @torch.no_grad()
    def evaluate(self, answer_and_context, attention_mask, labels):
        outputs = self.model(input_ids=answer_and_context, attention_mask=attention_mask, labels=labels)
        return outputs
    
    # [param] a batch of tokenization of answers and context
    # [param] a batch of attention mask
    # [param] a batch of labels
    # [return] outputs of the model, loss of the batch, questions of the batch
    @torch.no_grad()
    def batch_evaluate(self, batch_answer_and_context, attention_mask, labels):
        outputs = self.model(input_ids=batch_answer_and_context, attention_mask=attention_mask, labels=labels)
        questions = self.batch_question(batch_answer_and_context)
        return outputs, outputs.loss, questions

    # [param] a batch of tokenization of answers and context
    # [return] answers of the batch
    @torch.no_grad()
    def batch_question(self, batch_answer_and_context):
        outputs = self.model.generate(input_ids=batch_answer_and_context, max_new_tokens=self.max_a_len+self.max_q_len)
        questions = self.tokenizer.batch_decode(outputs, skip_special_tokens=True)
        return questions

    # [param] a batch of tokenization of answers and context
    # [param] a batch of attention mask
    # [param] a batch of labels
    # [return] the outputs of the model
    def forward(self, input_ids, attention_mask, labels):
        outputs = self.model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
        return outputs
    
    def get_embedding(self, batch):
        return self.model.encoder.embed_tokens(batch)
    
    def save(self, path):
        self.model.save_pretrained(path)

    def load(self, path):
        self.model = AutoModelForCausalLM.from_pretrained(path)

class QAModelGPT2(Module):
    def __init__(self, model_args, data_args, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        model_name = model_args.model
        self.tokenizer = AutoTokenizer.from_pretrained(model_name, padding_side='left')
        eos_token_id = 50256
        self.tokenizer.pad_token = self.tokenizer.eos_token
        self.tokenizer.pad_token_id = eos_token_id        
        self.model = GPT2LMHeadModel.from_pretrained(model_name)
        self.max_p_len = data_args.context_len
        self.max_q_len = data_args.question_len
        self.max_a_len = data_args.answer_len

    
    def tokenize(self, text):
        return self.tokenizer(text, 
                    padding="max_length",
                    max_length=self.max_p_len,
                    truncation=True,
                    return_tensors="pt")
    # [param] question
    # [param] context
    # [return] answer
    @torch.no_grad()
    def question_answer(self, question : str, context : str) -> str:   
        input_text = "question: "+ question +" context: " +  context
        
        input_ids = self.tokenize(input_text)
        outputs = self.model.generate(input_ids = input_ids, attention_mask = input_ids["attention_masks"])
        answer = self.tokenizer.decode(outputs, skip_special_tokens=True)
        return answer

    @torch.no_grad()
    def evaluate(self, question_and_context, attention_mask, labels):
        outputs = self.model(input_ids=question_and_context, attention_mask = attention_mask, labels=labels)
        return outputs
    
    # [param] a batch of tokenization of questions and context
    # [param] a batch of attention mask
    # [param] a batch of labels
    # [return] output of the model , loss of the batch, answers of the batch
    @torch.no_grad()
    def batch_evaluate(self, batch_question_and_context, attention_mask, labels):
        outputs = self.model(input_ids = batch_question_and_context, attention_mask = attention_mask, labels=labels)
        answers = self.batch_answer(batch_question_and_context, attention_mask)
        return outputs, outputs.loss, answers

    # [param] a batch of tokenization of questions and context
    # [return] answers of the batch
    @torch.no_grad()
    def batch_answer(self, batch_question_and_context, attention_mask):
        outputs = self.model.generate(batch_question_and_context, attention_mask = attention_mask)
        answers = self.tokenizer.batch_decode(outputs, skip_special_tokens=True)
        return answers

    # [param] a batch of tokenization of questions and context
    # [param] a batch of attention mask
    # [param] a batch of labels
    # [return] the outputs of the model
    def forward(self, input_ids, attention_mask, labels):
        outputs = self.model(input_ids=input_ids, attention_mask=attention_mask, labels=labels)
        return outputs
    
    def get_embedding(self, batch):
        return self.model.encoder.embed_tokens(batch)
    
    def save(self, path):
        self.model.save_pretrained(path)

    def load(self, path):
        self.model = GPT2LMHeadModel.from_pretrained(path)   

class QGModelGPT2(Module):
    def __init__(self, model_args, data_args, *args, **kwargs) -> None:
        super().__init__(*args, **kwargs)
        model_name = model_args.model
        self.tokenizer = GPT2Tokenizer.from_pretrained(model_name)
        self.model = GPT2LMHeadModel.from_pretrained(model_name)
        self.tokenizer.add_special_tokens({'pad_token': '[PAD]'})
        self.max_p_len = data_args.context_len
        self.max_q_len = data_args.question_len
        self.max_a_len = data_args.answer_len
    
    def tokenize(self, text):
        return self.tokenizer(text, 
                    padding="max_length",
                    max_length=self.max_p_len,
                    truncation=True,
                    return_tensors="pt")

    # [param] answer
    # [param] context
    # [return] question
    @torch.no_grad()
    def question_generate(self, answer : str, context : str) -> str:   
        input_text = "answer: "+ answer + " context: " + context
        
        input_ids = self.tokenize(input_text)
        outputs = self.model.generate(input_ids=input_ids, max_new_tokens=self.max_a_len+self.max_q_len)
        question = self.tokenizer.decode(outputs, skip_special_tokens=True)
        return question

    @torch.no_grad()
    def evaluate(self, answer_and_context, attention_mask, labels):
        outputs = self.model(input_ids=answer_and_context, attention_mask=attention_mask, labels=labels)
        return outputs
    
    # [param] a batch of tokenization of answers and context
    # [param] a batch of attention mask
    # [param] a batch of labels
    # [return] outputs of the model, loss of the batch, questions of the batch
    @torch.no_grad()
    def batch_evaluate(self, batch_answer_and_context, attention_mask, labels):
        outputs = self.model(input_ids=batch_answer_and_context, attention_mask=attention_mask, labels=labels)
        questions = self.batch_question(batch_answer_and_context)
        return outputs, outputs.loss, questions

    # [param] a batch of tokenization of answers and context
    # [return] answers of the batch
    @torch.no_grad()
    def batch_question(self, batch_answer_and_context):
        outputs = self.model.generate(input_ids=batch_answer_and_context, max_new_tokens=self.max_a_len+self.max_q_len)
        questions = self.tokenizer.batch_decode(outputs, skip_special_tokens=True)
        return questions

    # [param] a batch of tokenization of answers and context
    # [param] a batch of attention mask
    # [param] a batch of labels
    # [return] the outputs of the model
    def forward(self, input_ids, attention_mask, labels):
        outputs = self.model(input_ids=input_ids, attention_mask=attention_mask)
        return outputs
    
    def get_embedding(self, batch):
        return self.model.encoder.embed_tokens(batch)
    
    def save(self, path):
        self.model.save_pretrained(path)

    def load(self, path):
        self.model = GPT2LMHeadModel.from_pretrained(path)

