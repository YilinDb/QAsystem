export EX_NAME=/home/ubuntu/11411/src/output/qa-benchmark-Dec-7

python /home/ubuntu/11411/src/qg_ouput_generator.py \
    --model /11411/src/model-001.safetensors \
    --if_download True \
    --path squad_v2 \
    --num_train_epochs 1 \
    --question_len 128 \
    --context_len 512 \
    --answer_len 32 \
    --output_dir $EX_NAME/checkpoint/qa/ \
    --per_device_train_batch_size 6 \
    --per_device_eval_batch_size 16 \
    --logging_dir $EX_NAME/log/qa \
    --report_to tensorboard > $EX_NAME/error.log 2>&1 &