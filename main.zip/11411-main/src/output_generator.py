import logging
import os
import sys
import torch
import json

from arguments import ModelArguments, DataArguments, TrainerArguments
from dataset import *
from model import *
from trainer import *

from transformers import AutoConfig, HfArgumentParser, AutoModelForSeq2SeqLM, AutoTokenizer, T5ForConditionalGeneration
import torch
import numpy as np

logger = logging.getLogger(__name__)

def main():
    output_file_path = 'results.txt'

    parser = HfArgumentParser((ModelArguments, DataArguments, TrainerArguments))
    model_args, data_args, trainer_args = parser.parse_args_into_dataclasses()
    model_args: ModelArguments
    data_args: DataArguments
    trainer_args: TrainerArguments

    logging.basicConfig(
        format="%(asctime)s - %(levelname)s - %(name)s -   %(message)s",
        datefmt="%m/%d/%Y %H:%M:%S",
        level=logging.INFO if trainer_args.local_rank in [-1, 0] else logging.WARN,
    )

    logger.warning(
        "Process rank: %s, device: %s, n_gpu: %s, distributed training: %s, 16-bits training: %s",
        trainer_args.local_rank,
        trainer_args.device,
        trainer_args.n_gpu,
        bool(trainer_args.local_rank != -1),
        trainer_args.fp16,
    )

    # Replace 'your-model-name' with the actual model name or path
    device = "cuda:0"

    tokenizer = AutoTokenizer.from_pretrained("potsawee/t5-large-generation-squad-QuestionAnswer")
    model = AutoModelForSeq2SeqLM.from_pretrained("potsawee/t5-large-generation-squad-QuestionAnswer").to(device)

    # Load your test dataset
    eval_dataset = QADataset(
                            data_args=data_args,
                            if_train=False,
                            )
    counter=0
    with open(output_file_path, 'w') as output_file:
        for sample in eval_dataset:
            # Tokenize the test data
            tokenized_input = tokenizer("question: "+sample["question"]+" context: "+sample["context"],
                                        padding="max_length",
                                        max_length=512,
                                        truncation=True,
                                        return_tensors="pt",
            )

            # Run the model on the test dataset
            with torch.no_grad():
                outputs = model.generate(**tokenized_input.to(device), max_length=512).to(device)
                question_answer = tokenizer.decode(outputs[0], skip_special_tokens=False)
                question_answer = question_answer.replace(tokenizer.pad_token, "").replace(tokenizer.eos_token, "")
                answer = question_answer.split(tokenizer.sep_token)
                if len(answer) > 1 and answer[0] == sample["question"]:
                    answer = answer[1]
                    
                    output_file.write(f'generated: {answer}\n')
                    output_file.write(f'ground truth: {sample["answer"][0]}\n')
    
if __name__ == "__main__":
    main()