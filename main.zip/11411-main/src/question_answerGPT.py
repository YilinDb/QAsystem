import logging
import os
import sys

from arguments import ModelArguments, DataArguments, TrainerArguments
from dataset import *
from model import *
from trainer import *

from transformers import AutoConfig, AutoTokenizer, HfArgumentParser

logger = logging.getLogger(__name__)


def main():
    parser = HfArgumentParser((ModelArguments, DataArguments, TrainerArguments))
    model_args, data_args, trainer_args = parser.parse_args_into_dataclasses()
    model_args: ModelArguments
    data_args: DataArguments
    trainer_args: TrainerArguments

    logging.basicConfig(
        format="%(asctime)s - %(levelname)s - %(name)s -   %(message)s",
        datefmt="%m/%d/%Y %H:%M:%S",
        level=logging.INFO if trainer_args.local_rank in [-1, 0] else logging.WARN,
    )

    logger.warning(
        "Process rank: %s, device: %s, n_gpu: %s, distributed training: %s, 16-bits training: %s",
        trainer_args.local_rank,
        trainer_args.device,
        trainer_args.n_gpu,
        bool(trainer_args.local_rank != -1),
        trainer_args.fp16,
    )

    logger.info("================ Model Loading ===============")
    # TODO: Load your model
    model = QAModelGPT2(model_args, data_args)
    

    print(model)
    model.to(trainer_args.device)

    logger.info("================ Data Loading ================")
    train_dataset = QADataset(
        data_args=data_args,
        if_train=True,
    )

    eval_dataset = QADataset(
        data_args=data_args,
        if_train=False,
    )

    logger.info("================ Trainer Loading =============")
    # TODO: Load you trainer

    trainer = QATrainer(
        model=model,
        args=trainer_args,
        train_dataset=train_dataset,
        eval_dataset=eval_dataset,
        data_collator=QACollatorGPT(tokenizer=model.tokenizer, data_args=data_args),
    )

    logger.info("================ Training ====================")
    trainer.train()

    logger.info("================ Saving Model ================")
    # TODO: Change to output folder name
    model.save("new")
    trainer.tb_writer.close()


if __name__ == "__main__":
    main()
