import logging
import os
import sys
import torch

from arguments import ModelArguments, DataArguments, TrainerArguments
from dataset import *
from model import *
from trainer import *
from questioner import *

from transformers import AutoConfig, AutoTokenizer, HfArgumentParser

logger = logging.getLogger(__name__)


def main():
    parser = HfArgumentParser((ModelArguments, DataArguments, TrainerArguments))
    model_args, data_args, trainer_args = parser.parse_args_into_dataclasses()
    model_args: ModelArguments
    data_args: DataArguments
    trainer_args: TrainerArguments
    
    device = "cuda:0"
    ranking_model = RankingModel(model_args, data_args)
    qg_model = QGSystemLoad(model_args, data_args).to(device)
    questioner = QuestionerRankQ(qg_model, ranking_model)
    
    f = open(data_args.filename)
    lines = f.readlines()
    n = data_args.question_num
    
    output_path = f'{data_args.main_path}/generation_output.txt'
    
    with open(output_path, 'w') as output:
        for context in lines:
            questions = questioner.top_n_questions(context, n)
            for question in questions:
                output.write(question+"\n")
            output.write("\n============\n")
    
    f.close()
    


if __name__ == "__main__":
    main()
