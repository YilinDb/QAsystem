import nltk
from nltk import pos_tag, word_tokenize, RegexpParser
from nltk.corpus import stopwords
from model import *
from sklearn.metrics.pairwise import cosine_similarity
from sklearn.feature_extraction.text import TfidfVectorizer
import spacy


nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')
nltk.download('stopwords')

class Questioner():
    def __init__(self, qg_model, ranking_model):
        self.qg_model = qg_model
        self.ranking_model = ranking_model
    
    def get_entities(self, context):
        words = word_tokenize(context)
        filtered_words = [word for word in words if word.isalnum()]
        tagged_words = pos_tag(filtered_words)

        grammar = r"""
            NP: {<DT>?<JJ>*<NN>+}
        """
        chunk_parser = RegexpParser(grammar)
        tree = chunk_parser.parse(tagged_words)

        nouns = []
        for subtree in tree.subtrees():
            if subtree.label() == "NP":
                phrase = ' '.join(word for word, pos in subtree.leaves())
                nouns.append(phrase)

        nouns.sort(key=len)
        nouns.reverse()
        return nouns

    def get_verbal(self,context):
        words = word_tokenize(context)
        stop_words = set(stopwords.words('english'))
        filtered_words = [word.lower() for word in words if word.isalnum() and word.lower() not in stop_words]
        tagged_words = pos_tag(filtered_words)

        verbs = []
        for word, pos in tagged_words:
            if pos.startswith('VB'):
                verbs.append(word)

        verbs.sort(key=len)
        verbs.reverse()
        return verbs
    
    def unique_questions(self, questions, scored_question_dict,similarity_threshold, score_threshold):
        nonrep_questions = list(set(questions))
        
        low_score_ques = [q for q in nonrep_questions if scored_question_dict[q] < score_threshold]
        top_ques = [q for q in nonrep_questions if q not in low_score_ques]
        
        similar_groups = []
        
        for question in top_ques:
            found_group = False
            for group in similar_groups:
                for representative_question in group:
                    if cosine_similarity([self.ranking_model.embedding(question)], [self.ranking_model.embedding(representative_question)])[0][0] >= similarity_threshold:
                        group.append(question)
                        found_group = True
                        break
                if found_group:
                    break

            if not found_group:
                similar_groups.append([question])
        
        similar_groups = [sorted(group, key=lambda q: scored_question_dict[q], reverse=True) for group in similar_groups]
        similar_groups.sort(key=lambda group: scored_question_dict[group[0]], reverse=True)
        
        final_list = [group[0] for group in similar_groups]
        for group in similar_groups:
            final_list += list(group[1:])
        final_list += list(low_score_ques)
        return final_list

    
    def single_question(self, context, entity):
        #print("entity:", entity)
        #print("context:",context)
        question = self.qg_model.question_generate(entity, context)
        return question
    
    def top_n_questions(self, context, n):
        pass


class QuestionerRankQ(Questioner):
    
    def top_n_questions(self, context, n, words=[], similarity_threshold=0.7, score_threshold=10):
        if words==[]:
            verbal = self.get_verbal(context)
            noun = self.get_entities(context)
            words = noun + verbal
        #print("context:", context)
        print("words:", words)
        all_questions = []
        for word in words:
            question = self.single_question(context, word)
            all_questions.append(question)
        scored_question_dict_ls = self.ranking_model.rank(context, all_questions)
        scored_question_dict = {key:value for d in scored_question_dict_ls for key, value in d.items()}
        print("dict:",scored_question_dict)
        scored_questions = [list(d.keys())[0] for d in scored_question_dict_ls]
        rearranged_questions = self.unique_questions(scored_questions,scored_question_dict, similarity_threshold, score_threshold)
        print("rearranged:",rearranged_questions)
        top_n_questions = rearranged_questions[:n]
        return top_n_questions
    
    
    
    
class QuestionerRankEnt(Questioner):
    
    def top_n_questions(self, context, n):
        verbal = self.get_verbal(context)
        noun = self.get_entities(context)
        words = noun + verbal
        scored_words = self.ranking_model.rank(context, words)
        top_n_words = scored_words[:n]
        top_n_questions = []
        for word in top_n_words:
            question = self.single_question(context, word)
            top_n_questions.append(question)

        return top_n_questions