export EX_NAME=/home/ec2-user/11411/src/output/qa-benchmark-Nov-23

python /home/ec2-user/11411/src/benchmark_qa.py \
    --model mrm8488/t5-base-finetuned-squadv2 \
    --if_download True \
    --path squad_v2 \
    --num_train_epochs 3 \
    --question_len 128 \
    --context_len 512 \
    --answer_len 32 \
    --output_dir $EX_NAME/checkpoint/qa/ \
    --per_device_train_batch_size 6 \
    --per_device_eval_batch_size 16 \
    --logging_dir $EX_NAME/log/qa \
    --report_to tensorboard > $EX_NAME/error.log 2>&1 &