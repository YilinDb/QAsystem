export EX_NAME=/home/ec2-user/11411/src/output/qa-flan-t5-large-Nov-23


nohup python /home/ec2-user/11411/src/question_answer.py \
    --model google/flan-t5-large \
    --if_download True \
    --do_train True \
    --path squad_v2 \
    --num_train_epochs 3 \
    --question_len 128 \
    --context_len 512 \
    --answer_len 32 \
    --output_dir $EX_NAME/checkpoint/qa/ \
    --per_device_train_batch_size 4 \
    --per_device_eval_batch_size 4 \
    --logging_dir $EX_NAME/log/qa \
    --evaluation_strategy "steps" \
    --eval_steps 2 \
    --save_steps 3000 \
    --learning_rate 1e-5 \
    --logging_steps 3 \
    --optim adafactor \
    --report_to tensorboard > $EX_NAME/error.log 2>&1 &