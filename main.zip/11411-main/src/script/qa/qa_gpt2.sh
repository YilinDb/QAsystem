export EX_NAME=/home/ec2-user/11411/src/output/qa-GPT2-774M-Dec-3

nohup python /home/ec2-user/11411/src/question_answerGPT.py \
    --model gpt2-large \
    --if_download True \
    --do_train True \
    --path squad_v2 \
    --num_train_epochs 3 \
    --question_len 128 \
    --context_len 512 \
    --answer_len 512 \
    --output_dir $EX_NAME/checkpoint/qa/ \
    --per_device_train_batch_size 2 \
    --per_device_eval_batch_size 2 \
    --logging_dir $EX_NAME/log/qa \
    --evaluation_strategy "steps" \
    --eval_steps 5000 \
    --save_steps 5000 \
    --logging_steps 3 \
    --learning_rate 1e-5 \
    --fp16 \
    --report_to tensorboard > $EX_NAME/error.log 2>&1 &