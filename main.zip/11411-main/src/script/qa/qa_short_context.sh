#!/bin/bash
#cd /script


export EX_NAME=/home/ec2-user/11411/src/output/qa-short-context-Nov-23


nohup python question_answer.py \
    --model t5-base \
    --if_download False \
    --path squad_v2 \
    --do_train True \
    --train_path /home/ec2-user/11411/src/dataset/squad_train.json \
    --eval_path /home/ec2-user/11411/src/dataset/squad_validation.json \
    --num_train_epochs 3 \
    --question_len 128 \
    --context_len 512 \
    --answer_len 32 \
    --output_dir $EX_NAME/checkpoint/qa/ \
    --per_device_train_batch_size 12 \
    --per_device_eval_batch_size 12 \
    --logging_dir $EX_NAME/log/qa \
    --evaluation_strategy "steps" \
    --eval_steps 500 \
    --save_steps 5000 \
    --report_to tensorboard > $EX_NAME/error.log 2>&1 &
