export EX_NAME=/home/ec2-user/11411/src/output/qa-t5-base-Nov-22

nohup python /home/ec2-user/11411/src/question_answer.py \
    --model t5-base \
    --if_download True \
    --do_train True \
    --path squad_v2 \
    --num_train_epochs 3 \
    --question_len 128 \
    --context_len 512 \
    --answer_len 32 \
    --output_dir $EX_NAME/checkpoint/qa/ \
    --per_device_train_batch_size 6 \
    --per_device_eval_batch_size 6 \
    --logging_dir $EX_NAME/log/qa \
    --evaluation_strategy "steps" \
    --eval_steps 1 \
    --save_steps 5000 \
    --logging_steps 3 \
    --fp16 \
    --report_to tensorboard > $EX_NAME/error.log 2>&1 &
