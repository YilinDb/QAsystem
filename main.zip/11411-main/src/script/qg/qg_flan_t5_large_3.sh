export EX_NAME=/home/ec2-user/11411/src/output/qg-flan-t5-large-Nov-23-3
export CUDA_VISIBLE_DEVICES=6

nohup python /home/ec2-user/11411/src/question_generation.py \
    --model google/flan-t5-large \
    --if_download True \
    --do_train True \
    --path squad_v2 \
    --num_train_epochs 4 \
    --question_len 128 \
    --context_len 512 \
    --answer_len 32 \
    --output_dir $EX_NAME/checkpoint/qg/ \
    --per_device_train_batch_size 16\
    --per_device_eval_batch_size 16 \
    --logging_dir $EX_NAME/log/qg \
    --evaluation_strategy "steps" \
    --eval_steps 500 \
    --save_steps 1000 \
    --learning_rate 5e-5 \
    --logging_steps 3 \
    --optim adafactor \
    --report_to tensorboard > $EX_NAME/error.log 2>&1 &