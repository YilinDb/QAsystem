export EX_NAME=/home/ubuntu/11411/src/output/system-Dec-8

nohup python /home/ubuntu/11411/src/system.py \
    --qg_model /home/ubuntu/11411/src/output/qg_model \
    --qa_model /home/ubuntu/11411/src/output/qa_model \
    --few_shot mistralai/Mistral-7B-Instruct-v0.1 \
    --ranking_model OpenMatch/t5-ance\
    --if_download_dataset True \
    --dataset_path squad_v2 \
    --main_path $EX_NAME \
    --question_num 5 \
    --filename '/home/ubuntu/11411/src/data/squad_v2.txt' \
    --file_style True \
    --answer_len 32 \
    --question_len 128 \
    --context_len 512 \
    --output_dir $EX_NAME/output > $EX_NAME/error.log 2>&1 &

    