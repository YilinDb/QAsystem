import logging
import os
import sys
import torch
import random
import csv
import chardet


from arguments import ModelArguments,DataArguments,TrainerArguments,SystemArguments
from dataset import *
from model import *
from answerer import *
from questioner import *

from datasets import load_dataset
from random import randint
from transformers import AutoConfig, AutoTokenizer, HfArgumentParser, AutoModelForCausalLM
from metrics import *

nltk.download('punkt')
from nltk.tokenize import sent_tokenize

logger = logging.getLogger(__name__)




def generate_eval_file(prediction, ground_truth, indicator="our_model", save_name="/home/ubuntu/11411/src/eval_"):
    output_path = save_name+f"{indicator}.txt"
    with open(output_path, 'w') as output:
        for i in range(len(prediction)):
            output.write(prediction[i]+"\n")
            output.write(ground_truth[i]+"\n")
    return 


def chunk_context(context, max_len=300, min_len=150):
    sentences = re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', context)  # Splitting into sentences
    chunks = []
    current_chunk = ""

    for sentence in sentences:
        if len(current_chunk.split()) + len(sentence.split()) <= max_len:
            current_chunk += sentence + " "
        else:
            chunks.append(current_chunk.strip())
            current_chunk = sentence + " "

    if current_chunk:
        if len(current_chunk.split()) < min_len:
            chunks[-1] = chunks[-1]+current_chunk
        else:
            chunks.append(current_chunk.strip())

    return chunks

def is_yes_no_question(sentence):
    # Remove leading and trailing whitespaces
    sentence = sentence.strip()
    
    # Check if the sentence ends with a question mark
    if sentence.endswith('?'):
        # Check if the sentence starts with a word indicating a yes/no question
        if re.match(r'^(is|are|was|were|am|will|can|could|shall|should|would|have|has|had|do|does|did)', sentence.lower()):
            return True
    return False

def process_fewshot_output(str_list):
    ranking_number_pattern = re.compile(r'^\d+\.\s*')

    # Define a regular expression pattern for matching sentences starting with specific symbols
    symbol_pattern = re.compile(r'^[:;*\-]\s*')

    # Remove ranking numbers and sentences starting with specific symbols from each question
    removed = [symbol_pattern.sub('', ranking_number_pattern.sub('', item)) for item in str_list]
    
    res = [item for item in removed if len(item) > 3]

    return res
    

def qa_metric(few_shot_ans, qa_ans, twoMod_ans, standard_answers):
    
    print(f"{len(few_shot_ans)}, few_shot_ans:", few_shot_ans)
    print(f"{len(qa_ans)}, qa_ans: ", qa_ans)
    print(f"{len(twoMod_ans)}, twoMod_ans:", twoMod_ans)
    print(f"{len(standard_answers)}, standard_answers", standard_answers)
    
    #generate_eval_file(few_shot_ans, standard_answers, indicator='few_shot')
    #generate_eval_file(qa_ans, standard_answers)
    #generate_eval_file(twoMod_ans, standard_answers, indicator='two_model')
    
    fewshot_score = 0
    qa_score = 0
    twoMod_score = 0
    f1_fewshot = f1_list(few_shot_ans,standard_answers)
    f1_qa = f1_list(qa_ans,standard_answers)
    f1_twoMod = f1_list(twoMod_ans,standard_answers)
    fewshot_score += f1_fewshot
    qa_score += f1_qa
    twoMod_score += f1_twoMod
    
    em_fewshot = em_list(few_shot_ans, standard_answers)
    em_qa = em_list(qa_ans, standard_answers)
    em_twoMod = em_list(twoMod_ans, standard_answers)
    fewshot_score += em_fewshot
    qa_score += em_qa
    twoMod_score += em_twoMod
        
    bleu_fewshot = bleu_list(few_shot_ans, standard_answers)
    bleu_qa = bleu_list(qa_ans, standard_answers)
    bleu_twoMod = bleu_list(twoMod_ans, standard_answers)
    fewshot_score += bleu_fewshot
    qa_score += bleu_qa
    twoMod_score += bleu_twoMod
    
    meteor_fewshot = meteor_list(few_shot_ans, standard_answers)
    meteor_qa = meteor_list(qa_ans, standard_answers)
    meteor_twoMod = meteor_list(twoMod_ans, standard_answers)
    fewshot_score += meteor_fewshot
    qa_score += meteor_qa
    twoMod_score += meteor_twoMod
    
    rouge_fewshot = rouge_list(few_shot_ans, standard_answers)
    rouge_l_f_fewshot = rouge_fewshot['rouge-l']['f']
    rouge_qa = rouge_list(qa_ans, standard_answers)
    rouge_l_f_qa = rouge_qa['rouge-l']['f']
    rouge_twoMod = rouge_list(twoMod_ans, standard_answers)
    rouge_l_f_twoMod = rouge_twoMod['rouge-l']['f']
    fewshot_score += rouge_l_f_fewshot
    qa_score += rouge_l_f_qa
    twoMod_score += rouge_l_f_twoMod
    
    chrf_fewshot = chrf_list(few_shot_ans, standard_answers)
    chrf_qa = chrf_list(qa_ans, standard_answers)
    chrf_twoMod = chrf_list(twoMod_ans, standard_answers)
    fewshot_score += chrf_fewshot
    qa_score += chrf_qa
    twoMod_score += chrf_twoMod
    
    if fewshot_score > qa_score and fewshot_score > twoMod_score:
        indicator = "few shot model's answer: \n"
        answer = few_shot_ans
    elif qa_score > fewshot_score and qa_score > twoMod_score:
        indicator = "our qa model's answer: \n"
        answer = qa_ans
    elif twoMod_score > fewshot_score and twoMod_score > qa_score:
        indicator = "two layer models' answer: \n"
        answer = twoMod_ans
        
    return indicator, answer
    

def parse_line(line):
    parts = line.split()
    context = ''
    question = ''
    questions = []
    answer = ''
    answers = []
    in_answer = False
    in_question = False
    in_context = False
    has_answer = False
    for i in parts:
        if i == 'answer:' or i == 'Answer':
            has_answer = True
            if in_question and (question!= '') :
                questions.append(question)
                question = ''
            if in_answer and (answer!= '') :
                answers.append(answer)
                answer = ''
            in_answer = True
            in_question = False
            in_context = False
            continue
        if i == 'question:' or i == 'Question':
            if in_question and (question!= '') :
                questions.append(question)
                question = ''
            if in_answer and (answer!= '') :
                answers.append(answer)
                answer = ''
            in_answer = False
            in_question = True
            in_context = False
            continue
        if i == 'context:' or i == 'Context:':
            if in_question and (question!= '') :
                questions.append(question)
                question = ''
            if in_answer and (answer!= '') :
                answers.append(answer)
                answer = ''
            in_answer = False
            in_question = False
            in_context = True
            continue
        if in_answer:
            answer += i + " "
        if in_question:
            question += i + " "
        if in_context:
            context += i + " "
    # add the last question/answer if there is one
    if in_question and (question!= '') :
        questions.append(question)
        question = ''
    if in_answer and (answer!= '') :
        answers.append(answer)
        answer = ''
    res = []
    for q in questions:
        entry = {"context": context, "question": q}
        res.append(entry)
    if has_answer == False:
        answers = ['']
    return res, answers


def encode_menu(path_to_menu, extension='.txt.clean'):
    data = []
    answers = []
    common_path, input_filename = os.path.split(path_to_menu)
    common_path += '/'
    current_article = None
    current_context = None
    contexts = []
    with open(path_to_menu, newline='', encoding='utf-8') as csvfile:
        reader = csv.DictReader(csvfile, delimiter='\t')
        for row in reader:

            #print(row)
            if current_article != row['ArticleFile']:
                current_article = row['ArticleFile']
                path_to_context = os.path.join(common_path, row['ArticleFile'] + extension)
                with open(path_to_context, 'rb') as article_file:
                    result = chardet.detect(article_file.read())
                    encoding = result['encoding']
                with open(path_to_context, 'r', encoding=encoding) as article_file:
                    article_content = article_file.read()
                file_content = article_content.replace("\n", " ")
                # collect new context (no repetitive)
                current_context = file_content
                contexts.append(file_content)
                
            # if no question to encode, continue
            if row['Question'] == "NULL" or row['Question'] == "NOTTTT  FOUND":
                continue
            answer_value = row.get('Answer', '')
            if answer_value == "NULL":
                answer_value = ""
            data.append({
                "context": current_context,
                "question": row['Question']
            })
            answers.append(answer_value)
            #print("read context:", file_content[:100])
            #print("read question", row['Question'])
            #print("read answer:", answer_value)
            #print()
    return data, answers, contexts

def read_file(file_path, our_input=False, qg=False):
    # if not our input, file_path should be path to the question_answer pair file (the menu like file)
    res = []
    all_ans = []
    has_questions = False
    with open(file_path, 'r') as file:
        if our_input:
            for line in file:
                line = line.strip()
                if 'question:' in line.lower():
                    has_questions = True
                    tmp, answers= parse_line(line)
                    if tmp != '':
                        res = res + tmp
                    all_ans += answers
                else:
                    res.append(line)
        else:
            #read question_answer pair file 
            data, all_ans, contexts= encode_menu(file_path)
            if qg:
                res = contexts
            else:
                res = data  
                has_questions = True
    return has_questions, res, all_ans


class FewShotModel:
    def __init__(self, args, device):
        self.model = AutoModelForCausalLM.from_pretrained(args.few_shot)
        self.tokenizer = AutoTokenizer.from_pretrained(args.few_shot)
        self.validation = load_dataset(f"squad_v2")["validation"]
        self.train = load_dataset(f"squad_v2")["train"]
        self.device = device
    
    def get_example_qa(self, number):
        concat = ""
        for i in range(number):
            random = randint(0, len(self.train))
            #while self.train[random]["answers"]["text"] == []:
            #    random = randint(0, len(self.train))
            concat += "example " + str(i) + ": "
            concat += "question: " + self.train[i]["question"] + " "
            concat += "context: " + self.train[i]["context"] + " "
            concat += "answer: " + self.train[i]["answers"]["text"][0] + "\n"
        return concat
    
    def answer_question(self, question, context, nShot=2, provide_context=True, prompt0="Select related sentences in the context that could provide answers to the question : "):
        # if we only do 2 shots for all contexts... 
        # if want different examples before each context and question, replace concat0 by concat
        concat0 = self.get_example_qa(nShot)
        answers = []
        # Create a prompt with context and question for few-shot learning
        concat = concat0
        concat += "question: " + question + "\n"
        concat += "context: " + context + "\n"
        if is_yes_no_question(question):
            prompt = "Answer with yes or no (one word): "
        else:
            #if provide_context == True:
                #prompt = "select the senetence in original context that contain the answer:"
            #else:
            prompt = prompt0
        concat += prompt
            
        encodeds = self.tokenizer.apply_chat_template([{"role": "user", "content": "{}".format(concat)},], return_tensors="pt")
        print("context length:", len(encodeds[0]))
        model_inputs = encodeds.to(self.device)
        self.model.to(self.device)
        generated_ids = self.model.generate(model_inputs, max_new_tokens=1000, do_sample=True, use_cache=False)
        decoded = self.tokenizer.batch_decode(generated_ids)
        reply = decoded[0]
        # print("reply:", reply)
        prompt_index = reply.find(prompt)
        answer = reply[prompt_index + len(prompt):].strip()
        answer = answer.replace("[/INST]", "").replace("</s>", "")
        answer = answer.replace('\n', '')
        return answer
    
    def get_example_qg(self, number):
        concat = ""
        for i in range(number):
            random = randint(0, len(self.train))
            #while self.train[random]["answers"]["text"] == []:
            #    random = randint(0, len(self.train))
            concat += "example " + str(i) + ": "
            concat += "context: " + self.train[i]["context"] + " "
            concat += "question: " + self.train[i]["question"] + " "
            concat += "\n"
        return concat
           
    def generate_questions(self, context, num_questions=5, nShot=2, prompt="Ask 5 easiest questions related to the last context that could be answered directly with context message:"):
        if num_questions != 5 and prompt == "Ask 5 easiest questions related to the last context that could be answered directly with context message:":
            prompt = f"Ask {num_questions} easiest questions related to the last context that could be answered directly with context message:"
        concat = self.get_example_qg(nShot)
        concat += 'context:'+ context + '\n'
        concat += prompt
        generated_questions = []
        
        encodeds = self.tokenizer.apply_chat_template([{"role": "user", "content": "{}".format(concat)},], return_tensors="pt")
        model_inputs = encodeds.to(self.device)
        self.model.to(self.device)
        generated_ids = self.model.generate(model_inputs, max_new_tokens=1000, do_sample=True)
        decoded = self.tokenizer.batch_decode(generated_ids)
        reply = decoded[0]
        prompt_index = reply.find('1.')
        questions = reply[prompt_index-1:].strip()
        generated_questions = questions.replace("[/INST]", "").replace("</s>", "")
        return generated_questions
    
    def generate_words(self,context, prompt="give me some interesting facts from the context:"):
        concat = context + "\n" + prompt
        encodeds = self.tokenizer.apply_chat_template([{"role": "user", "content": "{}".format(concat)},], return_tensors="pt")
        model_inputs = encodeds.to(self.device)
        self.model.to(self.device)
        generated_ids = self.model.generate(model_inputs, max_new_tokens=1000, do_sample=True, use_cache=False)
        decoded = self.tokenizer.batch_decode(generated_ids)
        reply = decoded[0]
        prompt_index = reply.find(prompt)
        answer = reply[prompt_index + len(prompt):].strip()
        answer = answer.replace("[/INST]", "").replace("</s>", "")
        return answer


def main():
    parser = HfArgumentParser((SystemArguments))
    args = parser.parse_args_into_dataclasses()[0]
    args: SystemArguments
    data_args = DataArguments()
    model_args = ModelArguments()
    trainer_args = TrainerArguments(args.output_dir)
    
    torch.set_grad_enabled(False)
    
    model_args.ranking_model = args.ranking_model
    data_args.if_download = args.if_download_dataset
    data_args.path = args.dataset_path
    data_args.main_path = args.main_path
    data_args.question_num = args.question_num
    data_args.filename = args.filename
    data_args.context_len = args.context_len
    data_args.question_len = args.question_len
    data_args.answer_len = args.answer_len
    
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

    has_questions, all_data, standard_answers = read_file(args.filename, our_input=args.file_style)
    #print("has questions?", has_questions)
    # print("file data:", data_ls)
    #print("standard answers?:", standard_answers)
    ranking_model = RankingModel(model_args, data_args)
    few_shot = FewShotModel(args, device)
    
    
    # qa
    if has_questions:
        data_ls = all_data
        #for context in few_shot_ans:
        #    print("few_shot answer:", context)
            
        model_args.model = args.qa_model
        qa_model = QASystemLoad(model_args, data_args).to(device)
        answerer = Answerer(qa_model, ranking_model)
        
        output_path = f'{args.main_path}/answer_output.txt'
        few_shot_ans = []
        qa_ans = []
        twoMod_ans = []
        answer = ''
        count = 0
        with open(output_path, 'w') as output:
            with open('/home/ubuntu/11411/src/eval_qa_model_3.txt', 'w', buffering=1) as compare_model:
                with open('/home/ubuntu/11411/src/eval_fewshot_3.txt', 'w', buffering=1) as compare_fewshot:
                    with open('/home/ubuntu/11411/src/eval_twoMod_3.txt', 'w', buffering=1) as compare_twoMod:
                        for data in data_ls:
                            fewshot_answer = few_shot.answer_question(data['question'], data['context'], nShot=0, provide_context=False)
                            few_shot_ans.append(fewshot_answer)
                            if fewshot_answer.lower().strip() == "yes." or  fewshot_answer.lower().strip() == "yes" or fewshot_answer.lower().strip() == "no." or fewshot_answer.lower().strip() == "no":
                                qa_answer = fewshot_answer
                                qa_ans.append(fewshot_answer)
                                twoMod_answer = fewshot_answer
                                twoMod_ans.append(fewshot_answer)
                            else:
                                qa_answer = answerer.single_answer(data['context'], data['question'])
                                qa_ans.append(qa_answer)
                                new_context = fewshot_answer
                                twoMod_answer = answerer.single_answer(new_context, data['question'])
                                twoMod_ans.append(twoMod_answer)
                            compare_model.write(qa_answer+'\n')
                            compare_model.write(standard_answers[count]+'\n')
                            compare_model.flush()
                            compare_fewshot.write(fewshot_answer+'\n')
                            compare_fewshot.write(standard_answers[count]+'\n')
                            compare_fewshot.flush()
                            compare_twoMod.write(twoMod_answer+'\n')
                            compare_twoMod.write(standard_answers[count]+'\n')
                            compare_twoMod.flush()
                            count += 1
        
            # compare if there is answer
            if any(ans != "" for ans in standard_answers):
                indicator, answers = qa_metric(few_shot_ans, qa_ans, twoMod_ans, standard_answers)
                output.write(indicator)
                for answer in answers:
                    output.write(answer+"\n")
            else:
                #print(f"{len(few_shot_ans)}few_shot_ans:", few_shot_ans)
                #print(f"{len(qa_ans)}, qa_ans: ", qa_ans)
                #print(f"{len(twoMod_ans)}twoMod_ans:", twoMod_ans)
                for answer in twoMod_ans:
                    output.write(answer+"\n")
    #qg         
    else:
        model_args.model = args.qg_model
        qg_model = QGSystemLoad(model_args, data_args).to(device)
        questioner = QuestionerRankQ(qg_model, ranking_model)
        n = args.question_num
        
        output_path = f'{args.main_path}/generation_output.txt'
        with open(output_path, 'w') as output:
            finetuned = False
            for context in all_data:
                qg_questions = []
                qg_questions_withFSwords = []
                # model
                if len(context.split()) > 300:
                    chunks = chunk_context(context)
                    for chunk in chunks:
                        fs_words = process_fewshot_output(sent_tokenize(few_shot.generate_words(chunk)))
                        #print("few shot generated words:", fs_words)
                        qg_questions_chunk = questioner.top_n_questions(chunk, n)
                        qg_questions += qg_questions_chunk
                        qg_questions_withFSwords_chunk = questioner.top_n_questions(chunk, n, words=fs_words)
                        qg_questions_withFSwords += qg_questions_withFSwords_chunk
                        
                else:
                    fs_words = process_fewshot_output(sent_tokenize(few_shot.generate_words(context)))
                    #print("few shot generated words:", fs_words)
                    qg_questions = questioner.top_n_questions(context, n)
                    qg_questions_withFSwords = questioner.top_n_questions(context, n, words=fs_words)
                    
                # few shot
                fewshot_questions = few_shot.generate_questions(context=context, num_questions=n, nShot=0)
                '''
                if finetuned == True:
                    fewshot_questions = few_shot.generate_questions(context=context, num_questions=n, nShot=0)
                else:
                    fewshot_questions = few_shot.generate_questions(context=context, num_questions=n, nShot=0)
                    finetuned = True
                '''
                fewshot_questions = fewshot_questions.split('\n')
                fewshot_qs = process_fewshot_output(fewshot_questions)
                
                #print("fewshot_qs:", fewshot_qs)
                #print("qg_questions", qg_questions)
                #print("qg_questions_withFSwords:", qg_questions_withFSwords)
                all_questions = list(fewshot_qs) + list(qg_questions) + list(qg_questions_withFSwords)                
                random.shuffle(all_questions)
                for question in all_questions[:n]:
                    output.write(question+"\n")
                output.write("\n============\n")
                
                '''
                output.write("qg model output:\n")
                count = 1
                for question in qg_questions:
                    output.write(f"{count}. "+question+"\n")
                    count += 1
                
                print()
                output.write("few shot model output:\n")
                output.write(fewshot_questions+"\n")
                    
                output.write("\n============\n")
                '''
    
if __name__ == "__main__":
    main()
