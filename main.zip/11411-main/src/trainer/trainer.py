import logging
import os
from typing import Any, Dict, List
import torch
from torch import Tensor
from torch import nn
from torch.utils.data import Dataset
from transformers.trainer import Trainer, TRAINING_ARGS_NAME
from tqdm import tqdm
from torch.utils.tensorboard import SummaryWriter
from nltk.translate.bleu_score import corpus_bleu,sentence_bleu
from collections import Counter
import re
import string
import rouge
from rouge import Rouge
from nltk.translate.meteor_score import meteor_score
import torch.optim as optim
import nltk

nltk.download('wordnet')


logger = logging.getLogger(__name__)


def normalize(s):
    #Lower text and remove punctuation, articles and extra whitespace.
    lower = s.lower()
    
    exclude = set(string.punctuation)
    remove_punc = ''.join(ch for ch in lower if ch not in exclude)
    
    remove_articles = re.sub(r'\b(a|an|the)\b', ' ', remove_punc)
    
    white_space_fix = ' '.join(remove_articles.split())
    
    return white_space_fix
    
    '''
    def remove_articles(text):
        return re.sub(r'\b(a|an|the)\b', ' ', text)

    def white_space_fix(text):
        return ' '.join(text.split())

    def remove_punc(text):
        exclude = set(string.punctuation)
        return ''.join(ch for ch in text if ch not in exclude)

    def lower(text):
        return text.lower()

    return white_space_fix(remove_articles(remove_punc(lower(s))))
    '''


class QATrainer(Trainer):
    def __init__(self, model, args, train_dataset, eval_dataset, data_collator=None):
        self.model = model
        self.args = args
        super().__init__(model=self.model, args=self.args)  # default training arguments
        self.train_dataset = train_dataset
        self.eval_dataset = eval_dataset
        self.loss_fn = nn.CrossEntropyLoss()
        self.data_collator = data_collator
        self.dataloader = self.get_train_dataloader()
        self.global_step = 0
        self.tb_writer = SummaryWriter(log_dir=self.args.logging_dir)
        print(self.args.evaluation_strategy)
        print(self.args.eval_steps)
        print(self.args.save_steps)

    def get_train_dataloader(self):
        return torch.utils.data.DataLoader(
            self.train_dataset,
            batch_size=self.args.train_batch_size,
            shuffle=True,
            collate_fn=self.data_collator,
        )
    
    def get_eval_dataloader(self):
        return torch.utils.data.DataLoader(
            self.eval_dataset,
            batch_size=self.args.eval_batch_size,
            shuffle=True,
            collate_fn=self.data_collator,
        )

    def compute_loss(self, model, inputs, return_output=False):
        # model.train()
        ans = inputs["answer"]
        outputs = model.forward(input_ids=inputs["question+context"]["input_ids"], attention_mask=inputs["question+context"]["attention_mask"], labels=ans['input_ids'])        
        loss = outputs.loss
        # print(loss)
        return (loss, outputs) if return_output else loss

    def training_step(self, model, inputs):
        # print(args[0])
        self.global_step += 1
        model.train()
        
        return super(QATrainer, self).training_step(model, inputs)
    

    def f1_score(self, prediction, ground_truth):
        # both string
        #print("f1 prediction==========================")
        #print(prediction)
        #print("f1 ans==========================")
        #print(ground_truth)
        prediction_tokens = normalize(prediction).split()
        ground_truth_tokens = normalize(ground_truth).split()
        common = Counter(prediction_tokens) & Counter(ground_truth_tokens)
        num_same = sum(common.values())
        if num_same == 0:
            return 0
        precision = 1.0 * num_same / len(prediction_tokens)
        recall = 1.0 * num_same / len(ground_truth_tokens)
        f1 = (2 * precision * recall) / (precision + recall)
        return f1
    
    def f1_list(self, predictions,ground_truths):
        all_f1 = []
        for prediction, ground_truth in zip(predictions,ground_truths):
            if (prediction is None) or (prediction.strip() == "") or (ground_truth is None) or (ground_truth.strip() == ""):
                print("Problematic Rouge Prediction:", prediction)
                print("Problematic Rouge Reference:", ground_truth)
                print()
                continue
            f1 = self.f1_score(prediction,ground_truth)
            all_f1.append(f1)
        res = sum(all_f1)/len(all_f1)
        #print('batch avg f1 ==========================')
        #print(res)
        #print()
        return res

    def exact_match_score(self,prediction, ground_truth):
        #print("em input prediction==========================")
        #print(prediction)
        #print("em input ans==========================")
        #print(ground_truth)
        return (normalize(prediction) == normalize(ground_truth))

    def em_list(self,predictions, ground_truths):
        all_em = []
        for prediction, ground_truth in zip(predictions,ground_truths):
            if (prediction is None) or (prediction.strip() == "") or (ground_truth is None) or (ground_truth.strip() == ""):
                print("Problematic Rouge Prediction:", prediction)
                print("Problematic Rouge Reference:", ground_truth)
                print()
                continue
            em_score = self.exact_match_score(prediction,ground_truth)
            all_em.append(em_score)
        res = sum(all_em)/len(all_em)
        #print("avg batch em =============")
        #print(res)
        #print()
        return res
    

    def bleu(self,prediction, ground_truth):
        prediction_tokens = prediction.split()
        ground_truth_tokens = [ground_truth.split()]
        # sample: sentence_bleu([['this','is','truth'],['this','is','truth2'],...], ['this','is','guess'])
        bleu_score = sentence_bleu(ground_truth_tokens, prediction_tokens)   
        return bleu_score
    
    def bleu_list(self,prediction, ground_truth):
        
        refs = [[ref.split()] for ref in ground_truth]
        preds = [hyp.split() for hyp in prediction]
        #print("bleu input prediction==========================")
        #print(len(preds))
        #print(preds)
        #print("bleu input ground_truth==========================")
        #print(len(refs))
        #print(refs)
        bleu_score = corpus_bleu(refs, preds)   
        return bleu_score
    
    def rouge_list(self, predictions, ground_truths):
        rouge = Rouge()
        total_scores = {
        'rouge-1': {'f': 0.0, 'p': 0.0, 'r': 0.0},
        'rouge-2': {'f': 0.0, 'p': 0.0, 'r': 0.0},
        'rouge-l': {'f': 0.0, 'p': 0.0, 'r': 0.0}
        }
        for prediction,ground_truth in zip(predictions, ground_truths):
            #print("Prediction:", prediction)
            #print("Reference:", reference)
            #print()
            if (prediction is None) or (prediction.strip() == "") or (ground_truth is None) or (ground_truth.strip() == ""):
                print("Problematic Rouge Prediction:", prediction)
                print("Problematic Rouge Reference:", ground_truth)
                print()
                continue
            
            scores = rouge.get_scores(prediction, ground_truth)[0]

            # Accumulate scores
            for metric in total_scores.keys():
                for score_type in ['f', 'p', 'r']:
                    total_scores[metric][score_type] += scores[metric][score_type]
        
        num_pairs = len(predictions)
        average_scores = {metric: {score_type: total_scores[metric][score_type] / num_pairs for score_type in ['f', 'p', 'r']} for metric in total_scores.keys()}

        return average_scores
    
    def meteor(self, prediction, ground_truth):
        prediction_tokens = normalize(prediction).split()
        ground_truth_tokens = normalize(ground_truth).split()
        score = meteor_score([ground_truth_tokens], prediction_tokens)
        return score
    
    def meteor_list(self, predictions, ground_truths):
        total_meteor_score = 0.0
        for prediction, ground_truth in zip(predictions, ground_truths):
            if (prediction is None) or (prediction.strip() == "") or (ground_truth is None) or (ground_truth.strip() == ""):
                print("Problematic Rouge Prediction:", prediction)
                print("Problematic Rouge Reference:", ground_truth)
                print()
                continue
            score = self.meteor(prediction, ground_truth)
            total_meteor_score += score

        num_pairs = len(predictions)
        average_meteor_score = total_meteor_score / num_pairs

        return average_meteor_score
    
    def evaluate(
        self,
        eval_dataset,
        ignore_keys = True
    ) -> Dict[str, float]:
        self.model.eval()
        # return super().evaluate(eval_dataset, ignore_keys, metric_key_prefix)
        if eval_dataset is None:
            eval_dataset = self.eval_dataset
        dataloader = self.get_eval_dataloader()
        all_ans = []
        all_predictions = []
        all_loss = []
        all_f1 = []
        all_em = []
        all_bleu = []
        with torch.no_grad():
            for batch in tqdm(dataloader):
                ans = batch["raw_answer"]
                all_ans.extend(ans)

                device = self.args.device
                outputs, loss, predictions = self.model.batch_evaluate(batch["question+context"]["input_ids"].to(device),batch["question+context"]["attention_mask"].to(device),batch["answer"]["input_ids"].to(device))
                
                
                print("get predictions==========================")
                print(predictions)
                print("get ans==========================")
                print(ans)
                
                all_predictions.extend(predictions)

                all_loss.append(loss)

                f1 = self.f1_list(predictions,ans)
                all_f1.append(f1)

                em = self.em_list(predictions, ans)
                all_em.append(em)
                
                bleu = self.bleu_list(predictions, ans)
                all_bleu.append(bleu)
                
                
        # NOTE: REQUIRED: nltk.download('wordnet')
        avg_loss = sum(all_loss) / len(all_loss)
        avg_f1 = sum(all_f1) / len(all_f1)
        avg_em = sum(all_em) / len(all_em)
        avg_bleu = sum(all_bleu) / len(all_bleu)
        bleu_score = self.bleu_list(all_predictions,all_ans)
        meteor_score = self.meteor_list(all_predictions,all_ans)
        rouge_score = self.rouge_list(all_predictions, all_ans)
        rouge_1_f = rouge_score['rouge-1']['f']
        rouge_1_p = rouge_score['rouge-1']['p']
        rouge_1_r = rouge_score['rouge-1']['r']
        rouge_2_f = rouge_score['rouge-2']['f']
        rouge_2_p = rouge_score['rouge-2']['p']
        rouge_2_r = rouge_score['rouge-2']['r']
        rouge_l_f = rouge_score['rouge-l']['f']
        rouge_l_p = rouge_score['rouge-l']['p']
        rouge_l_r = rouge_score['rouge-l']['r']


        record = {}
        record[f'bleu_of_all_{self.global_step}'] = bleu_score
        record[f'avg_bleu_{self.global_step}'] = avg_bleu
        record[f'F1_{self.global_step}'] = avg_f1
        record[f'Exact match score_{self.global_step}'] = avg_em
        record[f'loss_{self.global_step}'] = avg_loss.detach().cpu().item()
        record[f'Meteor score_{self.global_step}'] = meteor_score
        record[f'rouge_1_f_score_{self.global_step}'] = rouge_1_f
        record[f'rouge_1_precision_{self.global_step}'] = rouge_1_p
        record[f'rouge_1_recall_{self.global_step}'] = rouge_1_r
        record[f'rouge_2_f_score_{self.global_step}'] = rouge_2_f
        record[f'rouge_2_precision_{self.global_step}'] = rouge_2_p
        record[f'rouge_2_recall_{self.global_step}'] = rouge_2_r
        record[f'rouge_l_f_score_{self.global_step}'] = rouge_l_f
        record[f'rouge_l_precision_{self.global_step}'] = rouge_l_p
        record[f'rouge_l_recall_{self.global_step}'] = rouge_l_r
        
        self.tb_writer.add_scalar('avg_bleu', avg_bleu, self.global_step)
        self.tb_writer.add_scalar('bleu_of_all', bleu_score, self.global_step)
        self.tb_writer.add_scalar('F1', avg_f1, self.global_step)
        self.tb_writer.add_scalar('Exact match score', avg_em, self.global_step)
        self.tb_writer.add_scalar('Loss', avg_loss.detach().cpu().item(), self.global_step)
        self.tb_writer.add_scalar('Meteor score',meteor_score,self.global_step)
        self.tb_writer.add_scalar('Rouge-1 F score', rouge_1_f, self.global_step)
        self.tb_writer.add_scalar('Rouge-1 Precision', rouge_1_p, self.global_step)
        self.tb_writer.add_scalar('Rouge-1 Recall', rouge_1_r, self.global_step)
        self.tb_writer.add_scalar('Rouge-2 F score', rouge_2_f, self.global_step)
        self.tb_writer.add_scalar('Rouge-2 Precision', rouge_2_p, self.global_step)
        self.tb_writer.add_scalar('Rouge-2 Recall', rouge_2_r, self.global_step)
        self.tb_writer.add_scalar('Rouge-l F score', rouge_l_f, self.global_step)
        self.tb_writer.add_scalar('Rouge-l Precision', rouge_l_p, self.global_step)
        self.tb_writer.add_scalar('Rouge-l Recall', rouge_l_r, self.global_step)
            
        #self.log(record)
        return record
    

    
    def _save(self, output_dir, _internal_call=False):
        '''
        os.makedirs(output_dir, exist_ok = True)
        torch.save(self.model,output_dir+'.pth')
        return
        '''
        self.model.save(output_dir)




class QGTrainer(Trainer):
    def __init__(self, model, args, train_dataset, eval_dataset, data_collator=None):
        self.model = model
        self.args = args
        super().__init__(model=self.model, args=self.args)  # default training arguments
        self.train_dataset = train_dataset
        self.eval_dataset = eval_dataset
        self.loss_fn = nn.CrossEntropyLoss()
        self.data_collator = data_collator
        self.dataloader = self.get_train_dataloader()
        self.global_step = 0
        self.tb_writer = SummaryWriter(log_dir=self.args.logging_dir)
        print(self.args.evaluation_strategy)
        print(self.args.eval_steps)
        print(self.args.save_steps)

    def get_train_dataloader(self):
        return torch.utils.data.DataLoader(
            self.train_dataset,
            batch_size=self.args.train_batch_size,
            shuffle=True,
            collate_fn=self.data_collator,
        )
    
    def get_eval_dataloader(self):
        return torch.utils.data.DataLoader(
            self.eval_dataset,
            batch_size=self.args.eval_batch_size,
            shuffle=True,
            collate_fn=self.data_collator,
        )

    def compute_loss(self, model, inputs, return_output=False):
        # model.train()
        question = inputs["question"]
        outputs = model.forward(input_ids=inputs["answer+context"]["input_ids"], attention_mask=inputs["answer+context"]["attention_mask"], labels=question['input_ids'])
        loss = outputs.loss
        return (loss, outputs) if return_output else loss

    def training_step(self, model, inputs):
        # print(args[0])
        self.global_step += 1
        model.train()
        return super(QGTrainer, self).training_step(model, inputs)
    

    def f1_score(self, prediction, ground_truth):
        # both string
        #print("f1 prediction==========================")
        #print(prediction)
        #print("f1 ans==========================")
        #print(ground_truth)
        prediction_tokens = normalize(prediction).split()
        ground_truth_tokens = normalize(ground_truth).split()
        common = Counter(prediction_tokens) & Counter(ground_truth_tokens)
        num_same = sum(common.values())
        if num_same == 0:
            return 0
        precision = 1.0 * num_same / len(prediction_tokens)
        recall = 1.0 * num_same / len(ground_truth_tokens)
        f1 = (2 * precision * recall) / (precision + recall)
        return f1
    
    def f1_list(self, predictions,ground_truths):
        all_f1 = []
        for prediction, ground_truth in zip(predictions,ground_truths):
            if (prediction is None) or (prediction.strip() == "") or (ground_truth is None) or (ground_truth.strip() == ""):
                print("Problematic Rouge Prediction:", prediction)
                print("Problematic Rouge Reference:", ground_truth)
                print()
                continue
            f1 = self.f1_score(prediction,ground_truth)
            all_f1.append(f1)
        res = sum(all_f1)/len(all_f1)
        #print('batch avg f1 ==========================')
        #print(res)
        #print()
        return res

    def exact_match_score(self,prediction, ground_truth):
        #print("em input prediction==========================")
        #print(prediction)
        #print("em input ans==========================")
        #print(ground_truth)
        return (normalize(prediction) == normalize(ground_truth))

    def em_list(self,predictions, ground_truths):
        all_em = []
        for prediction, ground_truth in zip(predictions,ground_truths):
            if (prediction is None) or (prediction.strip() == "") or (ground_truth is None) or (ground_truth.strip() == ""):
                print("Problematic Rouge Prediction:", prediction)
                print("Problematic Rouge Reference:", ground_truth)
                print()
                continue
            em_score = self.exact_match_score(prediction,ground_truth)
            all_em.append(em_score)
        res = sum(all_em)/len(all_em)
        #print("avg batch em =============")
        #print(res)
        #print()
        return res
    

    def bleu(self,prediction, ground_truth):
        prediction_tokens = prediction.split()
        ground_truth_tokens = [ground_truth.split()]
        # sample: sentence_bleu([['this','is','truth'],['this','is','truth2'],...], ['this','is','guess'])
        bleu_score = sentence_bleu(ground_truth_tokens, prediction_tokens)   
        return bleu_score
    
    def bleu_list(self,prediction, ground_truth):
        
        refs = [[ref.split()] for ref in ground_truth]
        preds = [hyp.split() for hyp in prediction]
        #print("bleu input prediction==========================")
        #print(len(preds))
        #print(preds)
        #print("bleu input ground_truth==========================")
        #print(len(refs))
        #print(refs)
        bleu_score = corpus_bleu(refs, preds)   
        return bleu_score
    
    def rouge_list(self, predictions, ground_truths):
        rouge = Rouge()
        total_scores = {
        'rouge-1': {'f': 0.0, 'p': 0.0, 'r': 0.0},
        'rouge-2': {'f': 0.0, 'p': 0.0, 'r': 0.0},
        'rouge-l': {'f': 0.0, 'p': 0.0, 'r': 0.0}
        }
        for prediction,ground_truth in zip(predictions, ground_truths):
            #print("Prediction:", prediction)
            #print("Reference:", reference)
            #print()
            if (prediction is None) or (prediction.strip() == "") or (ground_truth is None) or (ground_truth.strip() == ""):
                print("Problematic Rouge Prediction:", prediction)
                print("Problematic Rouge Reference:", ground_truth)
                print()
                continue
            
            scores = rouge.get_scores(prediction, ground_truth)[0]

            # Accumulate scores
            for metric in total_scores.keys():
                for score_type in ['f', 'p', 'r']:
                    total_scores[metric][score_type] += scores[metric][score_type]
        
        num_pairs = len(predictions)
        average_scores = {metric: {score_type: total_scores[metric][score_type] / num_pairs for score_type in ['f', 'p', 'r']} for metric in total_scores.keys()}

        return average_scores
    
    def meteor(self, prediction, ground_truth):
        prediction_tokens = normalize(prediction).split()
        ground_truth_tokens = normalize(ground_truth).split()
        score = meteor_score([ground_truth_tokens], prediction_tokens)
        return score
    
    def meteor_list(self, predictions, ground_truths):
        total_meteor_score = 0.0
        for prediction, ground_truth in zip(predictions, ground_truths):
            if (prediction is None) or (prediction.strip() == "") or (ground_truth is None) or (ground_truth.strip() == ""):
                print("Problematic Rouge Prediction:", prediction)
                print("Problematic Rouge Reference:", ground_truth)
                print()
                continue
            score = self.meteor(prediction, ground_truth)
            total_meteor_score += score

        num_pairs = len(predictions)
        average_meteor_score = total_meteor_score / num_pairs

        return average_meteor_score
    
    def evaluate(
        self,
        eval_dataset
    ) -> Dict[str, float]:
        self.model.eval()
        # return super().evaluate(eval_dataset, ignore_keys, metric_key_prefix)
        if eval_dataset is None:
            eval_dataset = self.eval_dataset
        dataloader = self.get_eval_dataloader()
        all_questions = []
        all_predictions = []
        all_loss = []
        all_f1 = []
        all_em = []
        all_bleu = []
        step_count = 0
        with torch.no_grad():
            for batch in tqdm(dataloader):
                question = batch["raw_question"]
                all_questions.extend(question)

                device = self.args.device
                outputs, loss, predictions = self.model.batch_evaluate(batch["answer+context"]["input_ids"].to(device),batch["answer+context"]["attention_mask"].to(device),batch["question"]["input_ids"].to(device))
                if step_count < 10:
                    print("get predictions==========================")
                    print(predictions)
                    print("get question==========================")
                    print(question)
                
                print("get predictions==========================")
                print(predictions)
                print("get ans==========================")
                print(question)
                
                all_predictions.extend(predictions)

                all_loss.append(loss)

                f1 = self.f1_list(predictions,question)
                all_f1.append(f1)

                em = self.em_list(predictions, question)
                all_em.append(em)
                
                bleu = self.bleu_list(predictions, question)
                all_bleu.append(bleu)
                
                step_count += 1

                
                
        # NOTE: REQUIRED: nltk.download('wordnet')
        avg_loss = sum(all_loss) / len(all_loss)
        avg_f1 = sum(all_f1) / len(all_f1)
        avg_em = sum(all_em) / len(all_em)
        avg_bleu = sum(all_bleu) / len(all_bleu)
        bleu_score = self.bleu_list(all_predictions,all_questions)
        meteor_score = self.meteor_list(all_predictions,all_questions)
        rouge_score = self.rouge_list(all_predictions, all_questions)
        rouge_1_f = rouge_score['rouge-1']['f']
        rouge_1_p = rouge_score['rouge-1']['p']
        rouge_1_r = rouge_score['rouge-1']['r']
        rouge_2_f = rouge_score['rouge-2']['f']
        rouge_2_p = rouge_score['rouge-2']['p']
        rouge_2_r = rouge_score['rouge-2']['r']
        rouge_l_f = rouge_score['rouge-l']['f']
        rouge_l_p = rouge_score['rouge-l']['p']
        rouge_l_r = rouge_score['rouge-l']['r']


        record = {}
        record[f'bleu_of_all_{self.global_step}'] = bleu_score
        record[f'avg_bleu_{self.global_step}'] = avg_bleu
        record[f'F1_{self.global_step}'] = avg_f1
        record[f'Exact match score_{self.global_step}'] = avg_em
        record[f'loss_{self.global_step}'] = avg_loss.detach().cpu().item()
        record[f'Meteor score_{self.global_step}'] = meteor_score
        record[f'rouge_1_f_score_{self.global_step}'] = rouge_1_f
        record[f'rouge_1_precision_{self.global_step}'] = rouge_1_p
        record[f'rouge_1_recall_{self.global_step}'] = rouge_1_r
        record[f'rouge_2_f_score_{self.global_step}'] = rouge_2_f
        record[f'rouge_2_precision_{self.global_step}'] = rouge_2_p
        record[f'rouge_2_recall_{self.global_step}'] = rouge_2_r
        record[f'rouge_l_f_score_{self.global_step}'] = rouge_l_f
        record[f'rouge_l_precision_{self.global_step}'] = rouge_l_p
        record[f'rouge_l_recall_{self.global_step}'] = rouge_l_r
        
        self.tb_writer.add_scalar('avg_bleu', avg_bleu, self.global_step)
        self.tb_writer.add_scalar('bleu_of_all', bleu_score, self.global_step)
        self.tb_writer.add_scalar('F1', avg_f1, self.global_step)
        self.tb_writer.add_scalar('Exact match score', avg_em, self.global_step)
        self.tb_writer.add_scalar('Loss', avg_loss.detach().cpu().item(), self.global_step)
        self.tb_writer.add_scalar('Meteor score',meteor_score,self.global_step)
        self.tb_writer.add_scalar('Rouge-1 F score', rouge_1_f, self.global_step)
        self.tb_writer.add_scalar('Rouge-1 Precision', rouge_1_p, self.global_step)
        self.tb_writer.add_scalar('Rouge-1 Recall', rouge_1_r, self.global_step)
        self.tb_writer.add_scalar('Rouge-2 F score', rouge_2_f, self.global_step)
        self.tb_writer.add_scalar('Rouge-2 Precision', rouge_2_p, self.global_step)
        self.tb_writer.add_scalar('Rouge-2 Recall', rouge_2_r, self.global_step)
        self.tb_writer.add_scalar('Rouge-l F score', rouge_l_f, self.global_step)
        self.tb_writer.add_scalar('Rouge-l Precision', rouge_l_p, self.global_step)
        self.tb_writer.add_scalar('Rouge-l Recall', rouge_l_r, self.global_step)
        
        #self.log(record)
        return record
    

    
    def _save(self, output_dir, _internal_call=False):
        '''
        os.makedirs(output_dir, exist_ok = True)
        torch.save(self.model,output_dir+'.pth')
        return
        '''
        self.model.save(output_dir)


class BenchmarkTrainer(QATrainer):
    def evaluate(
        self,
        eval_dataset
    ) -> Dict[str, float]:
        self.model.eval()
        # return super().evaluate(eval_dataset, ignore_keys, metric_key_prefix)
        if eval_dataset is None:
            eval_dataset = self.eval_dataset
        dataloader = self.get_eval_dataloader()
        all_ans = []
        all_predictions = []
        all_loss = []
        all_f1 = []
        all_em = []
        all_bleu = []
        with torch.no_grad():
            for batch in tqdm(dataloader):
                ans = batch["raw_answer"]

                device = self.args.device
                outputs, loss, predictions = self.model.batch_evaluate(batch["question+context"]["input_ids"].to(device),batch["question+context"]["attention_mask"].to(device),batch["answer"]["input_ids"].to(device))
                

                evict_list = []
                for i, prediction in enumerate(predictions):
                    if prediction.startswith("add") or prediction.startswith("divide") or prediction.startswith("power") or prediction.startswith("subtract") or prediction.startswith("multiply") or prediction.startswith("lcm"):
                        evict_list.append(i)
                for i in range(len(evict_list)):
                    predictions.pop(evict_list[len(evict_list)-1-i])
                    ans.pop(evict_list[len(evict_list)-1-i])
                all_predictions.extend(predictions)
                all_ans.extend(ans)

                print("get predictions==========================")
                print(predictions)
                print("get ans==========================")
                print(ans)

                all_loss.append(loss)

                f1 = self.f1_list(predictions,ans)
                all_f1.append(f1)

                em = self.em_list(predictions, ans)
                all_em.append(em)
                
                bleu = self.bleu_list(predictions, ans)
                all_bleu.append(bleu)
                
                
        # NOTE: REQUIRED: nltk.download('wordnet')
        avg_loss = sum(all_loss) / len(all_loss)
        avg_f1 = sum(all_f1) / len(all_f1)
        avg_em = sum(all_em) / len(all_em)
        avg_bleu = sum(all_bleu) / len(all_bleu)
        bleu_score = self.bleu_list(all_predictions,all_ans)
        meteor_score = self.meteor_list(all_predictions,all_ans)
        rouge_score = self.rouge_list(all_predictions, all_ans)
        rouge_1_f = rouge_score['rouge-1']['f']
        rouge_1_p = rouge_score['rouge-1']['p']
        rouge_1_r = rouge_score['rouge-1']['r']
        rouge_2_f = rouge_score['rouge-2']['f']
        rouge_2_p = rouge_score['rouge-2']['p']
        rouge_2_r = rouge_score['rouge-2']['r']
        rouge_l_f = rouge_score['rouge-l']['f']
        rouge_l_p = rouge_score['rouge-l']['p']
        rouge_l_r = rouge_score['rouge-l']['r']


        record = {}
        record[f'bleu_of_all_{self.global_step}'] = bleu_score
        record[f'avg_bleu_{self.global_step}'] = avg_bleu
        record[f'F1_{self.global_step}'] = avg_f1
        record[f'Exact match score_{self.global_step}'] = avg_em
        record[f'loss_{self.global_step}'] = avg_loss.detach().cpu().item()
        record[f'Meteor score_{self.global_step}'] = meteor_score
        record[f'rouge_1_f_score_{self.global_step}'] = rouge_1_f
        record[f'rouge_1_precision_{self.global_step}'] = rouge_1_p
        record[f'rouge_1_recall_{self.global_step}'] = rouge_1_r
        record[f'rouge_2_f_score_{self.global_step}'] = rouge_2_f
        record[f'rouge_2_precision_{self.global_step}'] = rouge_2_p
        record[f'rouge_2_recall_{self.global_step}'] = rouge_2_r
        record[f'rouge_l_f_score_{self.global_step}'] = rouge_l_f
        record[f'rouge_l_precision_{self.global_step}'] = rouge_l_p
        record[f'rouge_l_recall_{self.global_step}'] = rouge_l_r
        
        self.tb_writer.add_scalar('avg_bleu', avg_bleu, self.global_step)
        self.tb_writer.add_scalar('bleu_of_all', bleu_score, self.global_step)
        self.tb_writer.add_scalar('F1', avg_f1, self.global_step)
        self.tb_writer.add_scalar('Exact match score', avg_em, self.global_step)
        self.tb_writer.add_scalar('Loss', avg_loss.detach().cpu().item(), self.global_step)
        self.tb_writer.add_scalar('Meteor score',meteor_score,self.global_step)
        self.tb_writer.add_scalar('Rouge-1 F score', rouge_1_f, self.global_step)
        self.tb_writer.add_scalar('Rouge-1 Precision', rouge_1_p, self.global_step)
        self.tb_writer.add_scalar('Rouge-1 Recall', rouge_1_r, self.global_step)
        self.tb_writer.add_scalar('Rouge-2 F score', rouge_2_f, self.global_step)
        self.tb_writer.add_scalar('Rouge-2 Precision', rouge_2_p, self.global_step)
        self.tb_writer.add_scalar('Rouge-2 Recall', rouge_2_r, self.global_step)
        self.tb_writer.add_scalar('Rouge-l F score', rouge_l_f, self.global_step)
        self.tb_writer.add_scalar('Rouge-l Precision', rouge_l_p, self.global_step)
        self.tb_writer.add_scalar('Rouge-l Recall', rouge_l_r, self.global_step)
            
        #self.log(record)
        return record
    
    

class BenchmarkQGTrainer(QGTrainer):
    def evaluate(
        self,
        eval_dataset
    ) -> Dict[str, float]:
        self.model.eval()
        # return super().evaluate(eval_dataset, ignore_keys, metric_key_prefix)
        if eval_dataset is None:
            eval_dataset = self.eval_dataset
        dataloader = self.get_eval_dataloader()
        all_ans = []
        all_predictions = []
        all_loss = []
        all_f1 = []
        all_em = []
        all_bleu = []
        with torch.no_grad():
            for batch in tqdm(dataloader):
                ans = batch["raw_question"]

                device = self.args.device
                outputs, loss, predictions = self.model.batch_evaluate(batch["answer+context"]["input_ids"].to(device),batch["answer+context"]["attention_mask"].to(device),batch["question"]["input_ids"].to(device))
                

                evict_list = []
                for i, prediction in enumerate(predictions):
                    if prediction.startswith("add") or prediction.startswith("divide") or prediction.startswith("power") or prediction.startswith("subtract") or prediction.startswith("multiply") or prediction.startswith("lcm"):
                        evict_list.append(i)
                for i in range(len(evict_list)):
                    predictions.pop(evict_list[len(evict_list)-1-i])
                    ans.pop(evict_list[len(evict_list)-1-i])
                all_predictions.extend(predictions)
                all_ans.extend(ans)

                print("get predictions==========================")
                print(predictions)
                print("get ans==========================")
                print(ans)

                all_loss.append(loss)

                f1 = self.f1_list(predictions,ans)
                all_f1.append(f1)

                em = self.em_list(predictions, ans)
                all_em.append(em)
                
                bleu = self.bleu_list(predictions, ans)
                all_bleu.append(bleu)
                
                
        # NOTE: REQUIRED: nltk.download('wordnet')
        avg_loss = sum(all_loss) / len(all_loss)
        avg_f1 = sum(all_f1) / len(all_f1)
        avg_em = sum(all_em) / len(all_em)
        avg_bleu = sum(all_bleu) / len(all_bleu)
        bleu_score = self.bleu_list(all_predictions,all_ans)
        meteor_score = self.meteor_list(all_predictions,all_ans)
        rouge_score = self.rouge_list(all_predictions, all_ans)
        rouge_1_f = rouge_score['rouge-1']['f']
        rouge_1_p = rouge_score['rouge-1']['p']
        rouge_1_r = rouge_score['rouge-1']['r']
        rouge_2_f = rouge_score['rouge-2']['f']
        rouge_2_p = rouge_score['rouge-2']['p']
        rouge_2_r = rouge_score['rouge-2']['r']
        rouge_l_f = rouge_score['rouge-l']['f']
        rouge_l_p = rouge_score['rouge-l']['p']
        rouge_l_r = rouge_score['rouge-l']['r']


        record = {}
        record[f'bleu_of_all_{self.global_step}'] = bleu_score
        record[f'avg_bleu_{self.global_step}'] = avg_bleu
        record[f'F1_{self.global_step}'] = avg_f1
        record[f'Exact match score_{self.global_step}'] = avg_em
        record[f'loss_{self.global_step}'] = avg_loss.detach().cpu().item()
        record[f'Meteor score_{self.global_step}'] = meteor_score
        record[f'rouge_1_f_score_{self.global_step}'] = rouge_1_f
        record[f'rouge_1_precision_{self.global_step}'] = rouge_1_p
        record[f'rouge_1_recall_{self.global_step}'] = rouge_1_r
        record[f'rouge_2_f_score_{self.global_step}'] = rouge_2_f
        record[f'rouge_2_precision_{self.global_step}'] = rouge_2_p
        record[f'rouge_2_recall_{self.global_step}'] = rouge_2_r
        record[f'rouge_l_f_score_{self.global_step}'] = rouge_l_f
        record[f'rouge_l_precision_{self.global_step}'] = rouge_l_p
        record[f'rouge_l_recall_{self.global_step}'] = rouge_l_r
        
        self.tb_writer.add_scalar('avg_bleu', avg_bleu, self.global_step)
        self.tb_writer.add_scalar('bleu_of_all', bleu_score, self.global_step)
        self.tb_writer.add_scalar('F1', avg_f1, self.global_step)
        self.tb_writer.add_scalar('Exact match score', avg_em, self.global_step)
        self.tb_writer.add_scalar('Loss', avg_loss.detach().cpu().item(), self.global_step)
        self.tb_writer.add_scalar('Meteor score',meteor_score,self.global_step)
        self.tb_writer.add_scalar('Rouge-1 F score', rouge_1_f, self.global_step)
        self.tb_writer.add_scalar('Rouge-1 Precision', rouge_1_p, self.global_step)
        self.tb_writer.add_scalar('Rouge-1 Recall', rouge_1_r, self.global_step)
        self.tb_writer.add_scalar('Rouge-2 F score', rouge_2_f, self.global_step)
        self.tb_writer.add_scalar('Rouge-2 Precision', rouge_2_p, self.global_step)
        self.tb_writer.add_scalar('Rouge-2 Recall', rouge_2_r, self.global_step)
        self.tb_writer.add_scalar('Rouge-l F score', rouge_l_f, self.global_step)
        self.tb_writer.add_scalar('Rouge-l Precision', rouge_l_p, self.global_step)
        self.tb_writer.add_scalar('Rouge-l Recall', rouge_l_r, self.global_step)
            
        #self.log(record)
        return record
    
    
    